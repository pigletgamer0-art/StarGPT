# StarGPT v0.5.4 Alpha

Esta alpha corrige la separación entre cuenta y motor de IA. Crear una cuenta local ya no implica que exista un backend de IA. StarGPT Auto usa, en este orden: backend global configurado, Ollama configurado, o una API key personal existente.

## Ollama sin API key
En Ajustes > Modelos y proveedores puedes indicar la URL de Ollama, por ejemplo `http://192.168.1.10:11434/v1`, y el modelo, por ejemplo `qwen3:1.7b`.

Para conectar desde Android, Ollama debe escuchar en la red local. No expongas el puerto 11434 directamente a Internet.

# StarGPT for Android

Aplicación Android nativa con interfaz WebView local y puente Kotlin para red, archivos, voz y almacenamiento seguro.

## Funciones de esta versión

- Chat con OpenAI Responses API y proveedores compatibles que expongan `/responses`.
- Entrada multimodal: texto, imágenes y archivos de texto.
- Búsqueda web opcional usando la herramienta `web_search` de Responses API.
- Creación de archivos mediante bloques `artifact` generados por el modelo.
- Vista previa de HTML, Markdown, JSON, código y texto.
- Descarga de archivos a `Descargas/StarGPT`.
- Generación de imágenes mediante `/images/generations`.
- Galería y descarga de imágenes.
- Historial local de conversaciones.
- Voz a texto mediante el reconocimiento de Android.
- Lectura en voz alta con TextToSpeech.
- API key cifrada con Android Keystore (AES-GCM).
- Soporte de endpoints HTTP/HTTPS personalizados.

## Configuración

En Ajustes de la app:

- API base: `https://api.openai.com/v1`
- Modelo de chat sugerido: `gpt-5.6-luna`
- Modelo de imágenes sugerido: `gpt-image-2`
- Pega tu propia API key. Nunca se incluye una clave dentro del código ni del APK.

Los costos y límites dependen del proveedor configurado.

## Abrir en Android Studio

1. Abre esta carpeta como proyecto en Android Studio.
2. Espera la sincronización de Gradle.
3. Instala Android SDK 35 si Android Studio lo solicita.
4. Ejecuta `app` en un dispositivo Android 10 (API 29) o superior.

> Este paquete no incluye el archivo binario del Gradle Wrapper porque el entorno donde se generó el proyecto no tenía acceso al SDK/Gradle. Android Studio puede configurar/sincronizar Gradle; también puedes ejecutar `gradle wrapper --gradle-version 8.9` una vez si prefieres usar `./gradlew`.

## Compilar APK

En Android Studio: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

## Seguridad

No publiques una API key dentro del repositorio ni dentro del APK. La app guarda la clave localmente usando Android Keystore y la inserta en el encabezado `Authorization` solo al hacer solicitudes.

## v0.5 alpha
- Puter eliminado.
- Entrada como invitado.
- Registro e inicio de sesión StarGPT contra backend configurable.
- Founder PLUS para las primeras 20 cuentas, asignado por servidor.
- Proveedor Ollama con selector bloqueado para PLUS.
- Backend de referencia incluido en `server/`.
- Google Sign-In queda preparado en UI/configuración, pero requiere un OAuth Client ID real del proyecto Android antes de activarse.

## v0.5.5 Alpha — ampliación sobre el proyecto Android original

- Conserva el paquete `com.multiai.assistant`, la interfaz, historial, cuentas y funciones originales.
- Añade NVIDIA NIM y Together AI a los proveedores preconfigurados. Se admiten claves personales que se almacenan en Android Keystore, como las de los proveedores existentes.
- Añade en Ajustes > Modelos y proveedores > Mis proveedores API perfiles personalizados ilimitados en concepto (límite práctico: 100 por dispositivo): nombre, URL base HTTPS, ID de modelo, esquema de autenticación, clave separada y botones para activar, probar y eliminar.
- Los perfiles nuevos usan la API compatible con OpenAI `POST /chat/completions`. No son compatibles automáticamente con API REST de formato arbitrario; esos protocolos requieren adaptadores propios.
- La prueba de conexión consulta `GET /models`. Algunos proveedores no implementan esa ruta, por lo que una prueba fallida no implica necesariamente que `POST /chat/completions` falle.
- Las claves personales nunca se guardan en localStorage ni en el ZIP; allí solo van el nombre, URL, modelo, tipo de autenticación e ID del perfil. Al eliminar un perfil se borra también su clave del Keystore.
- Por seguridad, los nuevos perfiles personalizados requieren HTTPS: no introduzcas claves en servidores que no sean de confianza.
- Este ZIP es **código fuente Android**. No se ha compilado ni probado un APK v0.5.5 en un dispositivo; necesitas Android Studio + Android SDK para hacerlo. El APK anterior v0.5.4 no contiene estos cambios.


## v0.5.6 Alpha — Agregar una clave API

- En Modelos y proveedores aparece por defecto **un solo campo de clave** y el botón «Guardar y utilizar».
- El formato de la clave se reconoce **localmente**, sin enviarla a servicios externos para adivinar el proveedor.
- NVIDIA (`nvapi-`), OpenRouter (`sk-or-v1-`), Anthropic (`sk-ant-`), Groq (`gsk_`) y xAI (`xai-`) tienen prefijos identificables. OpenAI (`sk-proj-`) y Google (`AIza`) se presentan solo como posibilidades, corregibles manualmente.
- Los formatos ambiguos (por ejemplo `sk-`) requieren elegir el proveedor manualmente; una clave por sí sola no permite identificar todas las APIs.
- La clave se almacena bajo el ID de proveedor usando el Android Keystore existente. Los campos URL/modelo, perfiles anteriores y otras opciones siguen disponibles en «Configuración avanzada».
- La detección del formato no valida la clave ni implica que la API tenga saldo, cuota o acceso al modelo preconfigurado.
- Este proyecto puede empaquetarse sobre el APK de la v0.5.4 ya compilada; una recompilación y firma con el certificado de la versión instalada es preferible para preservar la posibilidad de actualizar sin desinstalar.

## v0.5.7 Alpha — registro y duplicados

- Al registrar una cuenta, nombre y correo se comprueban contra el registro del servidor **si se ha configurado uno**. La comparación ignora mayúsculas y espacios exteriores, y el servidor devuelve HTTP 409 cuando un valor ya está registrado.
- En modo local, los registros nuevos mantienen un índice local de nombre y correo para detectar duplicados en **ese dispositivo**. La app no puede consultar cuentas de otro teléfono sin un servidor compartido. Para cuentas locales antiguas, la lista de nombres podría estar incompleta hasta que se inicien sus sesiones; el almacenamiento nativo anterior sigue rechazando correos repetidos.
- El formulario distingue explícitamente el registro local del registro con servidor y requiere aceptación de la información sobre almacenamiento de datos. Invitado no necesita cuenta.
- Cuando falla un servidor configurado, no se crean cuentas locales de forma automática: se muestra el error para no eludir la unicidad global.
- Servidor de referencia: `server/server.js`, con nombres y correos únicos, contraseñas con sal y scrypt, login, consulta y eliminación de cuentas. **No hay servidor público alojado ni preconfigurado en el APK**. Para sincronizar entre dispositivos hay que desplegar un servicio HTTPS con una base de datos persistente.
- El APK alfa distribuido contiene la interfaz WebView actualizada sobre el ejecutable nativo anterior. La compilación nativa completa del ZIP necesita Android Studio. El nuevo APK tiene una **firma de desarrollo diferente**, por lo que puede requerir desinstalar versiones previas (lo que borra sus datos locales).
- No se ha verificado en un dispositivo real ni el despliegue multiusuario. No abras el backend como servicio público sin configurar HTTPS, limitación de intentos, verificación de correo y una política de privacidad adecuada.


## v0.5.8 Alpha — diagnóstico NVIDIA NIM

- Se reemplaza el modelo predeterminado antiguo `meta/llama-3.1-8b-instruct` por `nvidia/nemotron-3-super-120b-a12b`, listado actualmente en la documentación de NVIDIA Build. El modelo seleccionado anteriormente solo se migra si coincide exactamente con el valor predeterminado antiguo.
- En Modelos y proveedores > Reparar NVIDIA NIM hay controles para actualizar el modelo y probar **POST /v1/chat/completions**. Una prueba previa de GET /models no demostraba que las solicitudes reales de chat funcionaran.
- Los errores HTTP 410 muestran, cuando el proveedor lo entrega, el detalle del motivo; un 410 también puede derivarse de falta de acceso a inferencia en la cuenta y NO garantiza que el modelo sea el problema.
- Las claves permanecen en Android Keystore y no se copian en los archivos de proyecto.
- El APK reempaquetado está firmado con una clave de desarrollo **diferente**; instalarlo sobre un APK previo podría requerir desinstalar y perder datos locales. Antes de reinstalar, prueba cambiar el modelo en la v0.5.7 desde Configuración avanzada y conserva un respaldo de la app.
- No se ha validado la autenticación real con una clave de NVIDIA, porque no se dispone de una clave de prueba del usuario ni se debe solicitar que la comparta.


## StarGPT 0.5.9 alpha — Google + Interactions

**OAuth no está listo para producción hasta configurar Google Cloud y desplegar el servidor.** El APK v0.5.8 anterior no incluye estos cambios.

1. Configura la pantalla de consentimiento de Google Auth Platform y crea un **OAuth Web Client ID** y credenciales Android para el paquete `com.multiai.assistant` con SHA-1 del certificado con que firmas el APK.
2. Usa el mismo identificador de cliente **web**, no el identificador Android, al compilar y en el backend. En Android Studio: `./gradlew assembleDebug -PMULTIAI_GOOGLE_WEB_CLIENT_ID=xxx.apps.googleusercontent.com`; en el servidor: `GOOGLE_WEB_CLIENT_ID=xxx.apps.googleusercontent.com` y `TOKEN_SECRET` aleatorio de 32+ caracteres. Mantén el backend detrás de HTTPS, configura `MULTIAI_DB` en almacenamiento persistente y protege/copias de seguridad del archivo de cuentas.
3. No es posible crear una cuenta de **Google** solo con un nombre. El usuario selecciona su cuenta Google en el diálogo oficial; StarGPT verifica su ID token en el servidor. Si ya existe el `sub` de Google, recupera su perfil. Si no, solicita solamente el nombre de usuario **StarGPT**; el correo de Google se obtiene del token verificado. Si ya existe una cuenta StarGPT con el mismo correo pero de otro método, se rechaza el registro y se informa que debe usar el método anterior; no se vinculan cuentas automáticamente por correo.
4. `v059.js` mantiene el token de Google en memoria de la pantalla de registro; el servidor no guarda el token de Google, solo el identificador `sub`, correo verificado, nombre de usuario y fecha de creación; conserva el token de sesión de StarGPT. No recopila contactos, Drive, claves API o historial por iniciar sesión. El token de sesión existente sigue usando WebView localStorage; para publicación se debe migrar a almacenamiento de sesión nativo protegido y adoptar Credential Manager para el flujo OAuth.
5. Cuentas locales antiguas no se convierten silenciosamente en cuentas en línea; se necesita una función de vinculación explícita que verifique ambos métodos. El sistema de nombres únicos del archivo JSON requiere una **única instancia de Node** y almacenamiento persistente; para producción multi-instancia, migrar a base de datos transaccional con índices UNIQUE. **No se ha desplegado un servidor público ni comprobado OAuth en un teléfono.**
6. Dentro de Modelos y proveedores activa **Google Gemini · Interacciones** para usar `/v1/interactions` con tu propia API key Gemini, `store:false` y búsqueda Google opcional mediante Web. El modo con adjuntos sigue usando el flujo Gemini anterior. Google mantiene la API original `generateContent`; los modelos y cuotas disponibles dependen de tu cuenta y región. El código de la v0.5.8 permanece incluido.

El código fuente se entrega sin una nueva APK: para modificar el flujo nativo de OAuth hace falta compilar Kotlin con Android SDK, Gradle, credenciales OAuth e instalar/probar en un dispositivo. No conviertas el APK v0.5.8 con un simple reemplazo de HTML: su parte nativa no solicita el ID token, y el inicio de sesión verificado fallaría.

## v0.5.11-alpha — funciones interactivas inspiradas en ChatGPT

- En **Crear > Tarjetas interactivas**: creación manual (`Pregunta | Respuesta`), generación opcional de 5–12 tarjetas con la **API activa de StarGPT**, voltear, mezclar, marcar recordadas/falladas y repetir las falladas. El texto enviado para crear tarjetas con IA se comparte con el proveedor seleccionado; la creación manual no usa red. Si NVIDIA NIM devuelve HTTP 410 u otro error, se informa, no se inventan tarjetas.
- En **Crear > Gráficos interactivos**: pega 2–20 pares `etiqueta;valor` (o `etiqueta,valor`), alterna entre barras y líneas, elige un dato para ver su valor; soporta números negativos.
- Conjuntos y gráficos guardados en localStorage, separados por ID de cuenta **en ese dispositivo**. No se sincronizan con el servidor ni se suben a Google. El almacenamiento local no equivale a un respaldo: desinstalar o borrar datos de la aplicación puede eliminarlos.
- Se conserva la preparación de inicio de sesión con Google de v0.5.9 porque se pidió para las cuentas, pero se elimina el modo **Gemini Interactions** agregado por confusión. Estas herramientas no requieren Gemini.
- Las funciones de ChatGPT y su suscripción no se transfieren automáticamente a StarGPT. El modo IA necesita un proveedor compatible y su acceso API correspondiente; los modelos y precios dependen del proveedor.

**Estado:** cambios en código fuente y validaciones locales de JavaScript. No se ha compilado un APK v0.5.11 ni se ha probado el flujo completo en un teléfono. Para usar Google Sign-In funcional en producción hace falta configurar OAuth y un servidor HTTPS real.
