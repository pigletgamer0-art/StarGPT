@echo off
setlocal
where ollama >nul 2>nul
if errorlevel 1 (
  echo Ollama no esta instalado o no esta en PATH.
  echo Instala Ollama primero y vuelve a ejecutar este archivo.
  pause
  exit /b 1
)

echo Iniciando Ollama para la red local...
start "MultiAI Ollama" cmd /k "set OLLAMA_HOST=0.0.0.0:11434&& ollama serve"
timeout /t 3 /nobreak >nul

echo.
echo Preparando qwen3:1.7b...
ollama pull qwen3:1.7b

echo.
echo Busca la IPv4 de este PC y ponla en MultiAI asi:
echo http://IP-DE-ESTE-PC:11434/v1
ipconfig | findstr /i "IPv4"
echo.
echo Mantén la ventana de Ollama abierta mientras uses MultiAI.
pause
