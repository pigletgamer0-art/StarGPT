// MultiAI 0.5.8: NVIDIA NIM model migration + actual inference test (no secret in UI/logs).
(() => {
  'use strict';
  const BASE='https://integrate.api.nvidia.com/v1';
  const MODEL='nvidia/nemotron-3-super-120b-a12b';
  const $q = selector => document.querySelector(selector);
  function persistNvidiaSettings(){
    state.settings.provider='nvidia';
    state.settings.baseUrl=BASE;
    state.settings.model=MODEL;
    localStorage.setItem('multiai_settings',JSON.stringify(state.settings));
    const chip=$q('#modelChip');
    if(chip)chip.textContent='NVIDIA NIM · '+MODEL;
    const provider=$q('#panelProvider');if(provider)provider.value='nvidia';
    const model=$q('#panelModel');if(model)model.value=MODEL;
    const url=$q('#baseUrl');if(url)url.value=BASE;
    const hiddenModel=$q('#chatModel');if(hiddenModel)hiddenModel.value=MODEL;
    if(typeof updateKeyStatus==='function') updateKeyStatus();
  }
  function formatError(response){
    let detail='';
    try {
      const body=JSON.parse(response.body||'{}');
      detail=String(body.error?.message||body.error?.detail||body.detail||body.message||body.title||'');
    }catch{}
    const status=Number(response.status||0);
    if(status===410) return 'HTTP 410 de NVIDIA: '+(detail||'El modelo podría estar retirado, o tu cuenta podría no tener acceso a inferencia. Prueba otro modelo en NVIDIA Build y comprueba el permiso Public API Endpoints.');
    return 'HTTP '+status+': '+(detail||response.error||'No se pudo completar la solicitud.');
  }
  function showStatus(message,error=false){
    const target=$q('#v058NvidiaStatus');
    if(target){target.textContent=message;target.style.color=error?'#fda4af':'#a7f3d0';}
  }
  async function verifyChat(){
    if(!isAndroid || !Android.hasApiKey('nvidia')) throw Error('Agrega primero tu clave NVIDIA.');
    const response=await nativeRequest(BASE+'/chat/completions','POST',{
      model:MODEL,messages:[{role:'user',content:'Responde solo OK.'}],max_tokens:64,stream:false
    },'nvidia','bearer',{'Content-Type':'application/json'});
    if(!response.ok) throw Error(formatError(response));
    let data;
    try{data=JSON.parse(response.body||'{}');}catch{throw Error('NVIDIA respondió, pero el JSON no es válido.');}
    if(!Array.isArray(data.choices)||!data.choices.length)throw Error('La petición fue aceptada, pero no llegó una respuesta de chat.');
    return 'Chat NVIDIA operativo (HTTP '+response.status+').';
  }
  const original=window.openSettingsPanel;
  if(typeof original==='function'){
    window.openSettingsPanel=function(kind){
      original(kind);
      if(kind!=='providers')return;
      const panel=$q('#settingsPanel'),simple=$q('#v056Card');
      if(!panel||!simple||panel.querySelector('#v058Nvidia'))return;
      const box=document.createElement('section');box.id='v058Nvidia';
      box.style.cssText='margin-top:12px;padding:12px;border:1px solid #3f3f46;border-radius:14px';
      const title=document.createElement('strong');title.textContent='Reparar NVIDIA NIM';
      const about=document.createElement('p');about.style.cssText='font-size:12px;color:#bbb';
      about.textContent='Restablece el modelo sugerido y comprueba el chat con tu clave guardada. No borra tus conversaciones ni tu clave.';
      const reset=document.createElement('button');reset.type='button';reset.className='secondary';reset.textContent='Actualizar modelo NVIDIA';
      reset.addEventListener('click',()=>{persistNvidiaSettings();showStatus('Modelo actualizado. Prueba la conexión o vuelve al chat.');});
      const test=document.createElement('button');test.type='button';test.className='secondary';test.textContent='Probar chat NVIDIA';
      test.style.marginLeft='8px';
      test.addEventListener('click',async()=>{
        test.disabled=true;showStatus('Probando una solicitud real de chat…');
        try{persistNvidiaSettings();showStatus(await verifyChat());}
        catch(error){showStatus(error?.message||String(error),true);}
        finally{test.disabled=false;}
      });
      const status=document.createElement('p');status.id='v058NvidiaStatus';status.setAttribute('role','status');status.style.cssText='font-size:12px;overflow-wrap:anywhere';
      box.append(title,about,reset,test,status);simple.append(box);
    };
    try{openSettingsPanel=window.openSettingsPanel;}catch{}
  }
})();
