// MultiAI v0.5.9: verified Google account login + Gemini Interactions (opt-in).
(() => {
  'use strict';
  const $q=s=>document.querySelector(s);
  let pendingGoogleToken='';
  const error=m=>{const target=$q('#authError');if(target){target.textContent=m;target.setAttribute('role','alert');}};
  const backend=()=>String(getBackendUrl()||'').trim();
  const googleEndpoint=async(route,payload)=>{
    if(!/^https:\/\//i.test(backend()))throw Error('Configura un servidor MultiAI HTTPS para usar una cuenta Google recuperable.');
    const response=await nativeRequest(joinUrl(backend(),route),'POST',payload,'','none',{'Content-Type':'application/json'});
    if(!response.ok){let reason='No se pudo autenticar la cuenta con Google.';try{reason=JSON.parse(response.body||'{}').error||reason;}catch{}throw Error(reason);}
    return JSON.parse(response.body||'{}');
  };
  const signedIn=result=>{
    if(!result?.user?.id||!result?.token)throw Error('El servidor no pudo crear la sesión.');
    localStorage.removeItem('multiai_token');
    setAccount({...result.user,mode:'server'},result.token);
    pendingGoogleToken='';hideNameForm();hideAuthForm();toast(result.isNew?'Cuenta MultiAI creada con Google':'Bienvenido de nuevo');
  };
  function hideNameForm(){const el=$q('#v059GoogleRegister');if(el)el.remove();}
  function showNameForm(suggested){
    hideNameForm();const root=$q('#authGate .auth-card');if(!root)return;
    const form=document.createElement('form');form.id='v059GoogleRegister';form.style.cssText='display:grid;gap:10px;margin-top:12px;padding:12px;background:#232323;border-radius:14px';
    const heading=document.createElement('strong');heading.textContent='Nueva cuenta MultiAI';
    const copy=document.createElement('p');copy.style.cssText='text-align:left;margin:0;font-size:12px;color:#bbb';
    copy.textContent='Google ya verificó tu correo. Elige solamente un nombre de usuario para MultiAI; se guardarán nombre, correo verificado e identificador de Google en tu servidor configurado.';
    const name=document.createElement('input');name.id='v059NewName';name.autocomplete='nickname';name.maxLength=30;name.placeholder='Nombre de usuario (3–30 caracteres)';name.value=(suggested||'').trim().slice(0,30);name.style.cssText='padding:12px;background:#111;border:1px solid #555;border-radius:12px;color:white';
    const button=document.createElement('button');button.type='submit';button.className='auth-primary';button.textContent='Crear mi cuenta';
    const cancel=document.createElement('button');cancel.type='button';cancel.className='auth-link';cancel.textContent='Cancelar';cancel.onclick=()=>{pendingGoogleToken='';hideNameForm();error('Registro cancelado.');};
    form.append(heading,copy,name,button,cancel);root.append(form);
    form.onsubmit=async event=>{event.preventDefault();if(!pendingGoogleToken)return error('Vuelve a iniciar sesión con Google.');
      const displayName=name.value.trim();if(displayName.length<3||displayName.length>30)return error('Escribe un nombre de 3 a 30 caracteres.');
      button.disabled=true;button.textContent='Creando cuenta…';error('');
      try{signedIn(await googleEndpoint('auth/google/register',{idToken:pendingGoogleToken,name:displayName}));}
      catch(e){error(e.message||'Error al crear la cuenta.');}finally{button.disabled=false;button.textContent='Crear mi cuenta';}
    };name.focus();
  }
  // Override previous insecure handler, which trusted only an unverified client email.
  window.NativeBridgeCallbacks.onGoogleSignIn=async result=>{
    if(!result?.ok){pendingGoogleToken='';return error(result?.error||'No se pudo iniciar sesión con Google.');}
    if(!result.idToken){pendingGoogleToken='';return error('Google no entregó un token de identidad. Revisa la configuración OAuth.');}
    pendingGoogleToken=result.idToken;error('');
    try{const data=await googleEndpoint('auth/google/lookup',{idToken:pendingGoogleToken});
      if(data.needsName){showNameForm(data.googleName||'');return;}
      signedIn(data);
    }catch(e){pendingGoogleToken='';error(e.message||'No se pudo verificar la cuenta Google.');}
  };
})();
