// MultiAI v0.5.6-alpha: a single API key input with offline, conservative provider recognition.
// Never send a pasted key to a third-party service for detection. The Android bridge stores
// secrets under the provider's key ID; WebView only stores the public provider selection.
(function () {
  'use strict';
  const $one = selector => document.querySelector(selector);
  const BUILT_IN = ['openai', 'nvidia', 'together', 'anthropic', 'gemini', 'groq',
    'deepseek', 'mistral', 'xai', 'openrouter'];
  const suggest = Object.freeze([
    {pattern: /^nvapi-[\w-]{8,}$/i, id: 'nvidia', hint: 'Formato de NVIDIA NIM'},
    {pattern: /^sk-or-v1-[\w-]{8,}$/i, id: 'openrouter', hint: 'Formato de OpenRouter'},
    {pattern: /^sk-ant-[\w-]{8,}$/i, id: 'anthropic', hint: 'Formato de Anthropic'},
    {pattern: /^gsk_[\w-]{8,}$/i, id: 'groq', hint: 'Formato de Groq'},
    {pattern: /^xai-[\w-]{8,}$/i, id: 'xai', hint: 'Formato de xAI'},
    {pattern: /^sk-proj-[\w-]{8,}$/i, id: 'openai', hint: 'Posible clave de OpenAI'},
    {pattern: /^AIza[\w-]{16,}$/, id: 'gemini', hint: 'Posible clave de Google/Gemini'}
  ]);
  let manual = false;

  function recognize(value) {
    const key = String(value || '').trim();
    if (!key) return null;
    return suggest.find(row => row.pattern.test(key)) || null;
  }

  function selectProvider(id) {
    const p = PROVIDERS[id];
    if (!p) throw new Error('Proveedor no disponible.');
    state.settings.provider = id;
    state.settings.baseUrl = p.base || '';
    state.settings.model = p.model || '';
    localStorage.setItem('multiai_settings', JSON.stringify(state.settings));
    const chip = $one('#modelChip');
    if (chip) chip.textContent = p.label + ' · ' + p.model;
    const control = $one('#panelProvider');
    if (control) control.value = id;
    if (typeof updateKeyStatus === 'function') updateKeyStatus();
  }

  function renderSaved() {
    const root = $one('#v056Saved');
    if (!root) return;
    const saved = BUILT_IN.filter(id => Android.hasApiKey(id));
    root.replaceChildren();
    if (!saved.length) {
      const message = document.createElement('p');
      message.style.cssText = 'font-size:13px;color:#aaa';
      message.textContent = 'Aún no tienes claves guardadas.';
      root.appendChild(message);
      return;
    }
    const title = document.createElement('p');
    title.textContent = 'Mis claves guardadas';
    title.style.cssText = 'font-weight:700;margin:12px 0 4px';
    root.appendChild(title);
    for (const id of saved) {
      const row = document.createElement('div');
      row.className = 'provider-key-row';
      row.style.cssText = 'display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap;padding:10px 0';
      const label = document.createElement('span');
      label.textContent = '🔒 ' + PROVIDERS[id].label + (state.settings.provider === id ? ' · En uso' : '');
      const use = document.createElement('button');
      use.type = 'button'; use.className = 'secondary'; use.textContent = 'Usar';
      use.addEventListener('click', () => { selectProvider(id); renderSaved(); showResult(PROVIDERS[id].label + ' seleccionado.'); });
      const remove = document.createElement('button');
      remove.type = 'button'; remove.className = 'secondary'; remove.textContent = 'Quitar';
      remove.addEventListener('click', () => {
        if (!confirm('¿Quitar la clave guardada de ' + PROVIDERS[id].label + '?')) return;
        Android.clearApiKey(id);
        if (state.settings.provider === id) selectProvider('multiai');
        renderSaved(); showResult('Clave eliminada.');
      });
      row.append(label, use, remove);
      root.appendChild(row);
    }
  }

  function showResult(message, error = false) {
    const node = $one('#v056Result');
    if (node) { node.textContent = message; node.style.color = error ? '#fda4af' : '#a7f3d0'; }
  }

  function refreshDetector() {
    const input = $one('#v056Key');
    const select = $one('#v056Provider');
    const hint = $one('#v056Hint');
    if (!input || !select || !hint) return;
    const guess = recognize(input.value);
    const showSelect = manual || (input.value.trim().length > 0 && !guess);
    select.closest('label').style.display = showSelect ? 'flex' : 'none';
    if (guess && !manual) {
      select.value = guess.id;
      hint.textContent = guess.hint + ' → ' + PROVIDERS[guess.id].label + '. Puedes cambiarlo si la identificación es incorrecta.';
    } else if (input.value.trim() && !guess) {
      hint.textContent = 'No se puede reconocer con seguridad el proveedor por esta clave. Elígelo en la lista.';
    } else if (manual) {
      hint.textContent = 'Elige el proveedor al que pertenece tu clave.';
    } else {
      hint.textContent = 'Pega tu clave. La identificación se realiza en tu dispositivo.';
    }
    if (!manual && !guess) select.value = '';
  }

  function makeSimpleCard(panel) {
    const card = document.createElement('section');
    card.className = 'panel-card';
    card.id = 'v056Card';
    card.innerHTML = `<h3>Agregar API</h3>
      <p style="color:#bbb;font-size:13px">Pega una clave y MultiAI intentará reconocer su proveedor. No es necesario escribir URL ni modelo para los proveedores incluidos.</p>
      <label class="field"><span>Clave API</span>
        <input id="v056Key" type="password" autocomplete="new-password" autocorrect="off" autocapitalize="off" spellcheck="false" placeholder="Pega tu clave aquí"></label>
      <p id="v056Hint" role="status" style="font-size:12px;color:#aaa;margin:6px 0"></p>
      <label class="field" id="v056ProviderField" style="display:none"><span>Proveedor de esta clave</span>
        <select id="v056Provider"><option value="">Selecciona un proveedor</option></select></label>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px">
        <button type="button" class="primary" id="v056Save">Guardar y utilizar</button>
        <button type="button" class="secondary" id="v056Change">Elegir proveedor</button>
      </div>
      <p id="v056Result" role="status" style="font-size:12px;color:#aaa"></p>
      <div id="v056Saved"></div>
      <button type="button" class="secondary" id="v056Advanced" style="margin-top:10px">Configuración avanzada ▾</button>`;
    const chooser = card.querySelector('#v056Provider');
    for (const id of BUILT_IN) {
      const option = document.createElement('option');
      option.value = id;
      option.textContent = PROVIDERS[id].label;
      chooser.appendChild(option);
    }
    const first = panel.querySelector('.panel-head');
    if (first) first.after(card); else panel.prepend(card);
    const input = card.querySelector('#v056Key');
    input.addEventListener('input', () => { showResult(''); refreshDetector(); });
    card.querySelector('#v056Change').addEventListener('click', () => {
      manual = !manual;
      card.querySelector('#v056Change').textContent = manual ? 'Detectar automáticamente' : 'Elegir proveedor';
      refreshDetector();
    });
    card.querySelector('#v056Save').addEventListener('click', () => {
      try {
        if (!isAndroid || !Android.saveApiKey) throw new Error('Esta función requiere la aplicación Android.');
        const key = input.value.trim();
        if (!key || /\s/.test(key)) throw new Error('Introduce una clave API válida, sin espacios.');
        const guess = recognize(key);
        const id = manual || !guess ? chooser.value : guess.id;
        if (!id || !BUILT_IN.includes(id)) throw new Error('Selecciona el proveedor de esta clave.');
        Android.saveApiKey(id, key);
        input.value = '';
        selectProvider(id);
        manual = false;
        card.querySelector('#v056Change').textContent = 'Elegir proveedor';
        refreshDetector();
        renderSaved();
        showResult('Clave guardada para ' + PROVIDERS[id].label + '. Ya puedes utilizarla en el chat.');
      } catch (error) { showResult(error.message || String(error), true); }
    });
    return card;
  }

  const previous = window.openSettingsPanel;
  if (typeof previous === 'function') {
    window.openSettingsPanel = function (kind) {
      previous(kind);
      if (kind !== 'providers') return;
      const panel = $one('#settingsPanel');
      if (!panel) return;
      manual = false;
      const card = makeSimpleCard(panel);
      const advancedCards = () => [...panel.querySelectorAll('.panel-card')].filter(el => el !== card);
      advancedCards().forEach(el => { el.style.display = 'none'; });
      card.querySelector('#v056Advanced').addEventListener('click', e => {
        const advanced = advancedCards();
        const opened = advanced.some(el => el.style.display !== 'none');
        advanced.forEach(el => { el.style.display = opened ? 'none' : ''; });
        e.currentTarget.textContent = opened ? 'Configuración avanzada ▾' : 'Configuración avanzada ▴';
      });
      renderSaved();
      refreshDetector();
    };
    try { openSettingsPanel = window.openSettingsPanel; } catch { /* Global lexical binding is not writable on some WebViews. */ }
  }
  window.addEventListener('load', () => {
    const version = $one('#version');
    if (version) version.textContent = '0.5.6 alpha';
  });
  // Pure detection function exported only for offline tests. No key is exported or persisted.
  window.MultiAIKeyDetector = recognize;
})();
