// MultiAI v0.5.5-alpha: multiple independent API connections on the original Android app.
// Only non-secret profile metadata goes into localStorage. API keys remain in Android Keystore.
(function () {
  'use strict';
  const STORAGE = 'multiai_custom_api_profiles_v1';
  const prefix = 'user_';
  const q = selector => document.querySelector(selector);
  const html = value => escapeHtml(String(value ?? ''));
  const knownAuth = new Set(['bearer', 'x-api-key', 'api-key', 'x-goog-api-key']);
  const profiles = new Map();

  function validatedBase(value) {
    const input = String(value ?? '').trim();
    let parsed;
    try { parsed = new URL(input); } catch { throw new Error('Escribe una URL completa, por ejemplo https://servidor.com/v1'); }
    if (parsed.protocol !== 'https:') throw new Error('Para proteger tu clave API, este proveedor debe usar HTTPS.');
    if (parsed.username || parsed.password || parsed.search || parsed.hash) throw new Error('La URL no debe contener usuario, contraseña, parámetros ni fragmentos.');
    return parsed.href.replace(/\/$/, '');
  }

  function validateProfile(raw) {
    const name = String(raw.name ?? '').trim().slice(0, 60);
    const model = String(raw.model ?? '').trim().slice(0, 180);
    const auth = String(raw.auth ?? 'bearer').trim();
    if (!name || !model) throw new Error('El nombre y el modelo son obligatorios.');
    if (!knownAuth.has(auth)) throw new Error('Este tipo de autenticación no está disponible.');
    const base = validatedBase(raw.base);
    return { name, model, auth, base };
  }

  function validId(id) { return typeof id === 'string' && /^user_[a-z0-9]{8,40}$/.test(id); }
  function register(id, data) {
    const p = validateProfile(data);
    profiles.set(id, p);
    PROVIDERS[id] = { label: p.name, kind: 'chat', base: p.base, model: p.model, auth: p.auth };
    return p;
  }

  function persist() {
    localStorage.setItem(STORAGE, JSON.stringify([...profiles].map(([id, p]) => ({ id, ...p }))));
  }
  function restore() {
    let stored = [];
    try { stored = JSON.parse(localStorage.getItem(STORAGE) || '[]'); } catch { /* malformed old config */ }
    if (!Array.isArray(stored)) return;
    for (const row of stored.slice(0, 100)) {
      try { if (validId(row.id)) register(row.id, row); } catch { /* skip unsafe or invalid entries */ }
    }
  }
  restore();

  function syncActiveProfile() {
    const profile = PROVIDERS[state.settings.provider];
    if (!profile || !profiles.has(state.settings.provider)) return;
    state.settings.baseUrl = profile.base;
    state.settings.model = profile.model;
    const chip = q('#modelChip');
    if (chip) chip.textContent = profile.label + ' · ' + profile.model;
  }
  syncActiveProfile();

  function refreshStatus(message, isError = false) {
    const el = q('#v055Result');
    if (el) { el.textContent = message; el.style.color = isError ? '#fda4af' : '#a7f3d0'; }
  }

  function profileOptions(select, selectedId) {
    if (!select) return;
    for (const [id, p] of profiles) {
      if ([...select.options].some(opt => opt.value === id)) continue;
      const option = document.createElement('option');
      option.value = id;
      option.textContent = p.name;
      select.appendChild(option);
    }
    if (selectedId && PROVIDERS[selectedId]) select.value = selectedId;
  }

  function rowsHtml() {
    if (!profiles.size) return '<p style="color:#bbb">Todavía no has añadido ninguna API propia.</p>';
    return [...profiles].map(([id, p]) => {
      const saved = isAndroid && Android.hasApiKey(id);
      return `<div class="provider-key-row" style="margin:12px 0">
        <b>${html(p.name)}</b> <small>${saved ? '🔒 Clave guardada' : 'Sin clave'}</small>
        <div style="font-size:12px;color:#aaa;overflow-wrap:anywhere">${html(p.base)} · ${html(p.model)}</div>
        <label class="field"><span>Clave API ${html(p.name)}</span>
          <input id="v055Key_${id}" type="password" autocomplete="new-password" placeholder="Pega aquí tu clave API"></label>
        <div style="display:flex;gap:6px;flex-wrap:wrap">
          <button type="button" class="primary" data-api-action="save" data-api-id="${id}">Guardar clave</button>
          <button type="button" class="secondary" data-api-action="use" data-api-id="${id}">Usar modelo</button>
          <button type="button" class="secondary" data-api-action="test" data-api-id="${id}">Probar</button>
          <button type="button" class="secondary" data-api-action="delete" data-api-id="${id}">Eliminar perfil</button>
        </div>
      </div>`;
    }).join('');
  }

  function renderRows() {
    const el = q('#v055Profiles');
    if (el) el.innerHTML = rowsHtml();
    profileOptions(q('#panelProvider'), state.settings.provider);
    profileOptions(q('#providerSelect'), state.settings.provider);
  }

  function selectProfile(id) {
    const p = PROVIDERS[id];
    if (!p || !profiles.has(id)) throw new Error('Este perfil ya no existe.');
    state.settings.provider = id;
    state.settings.baseUrl = p.base;
    state.settings.model = p.model;
    localStorage.setItem('multiai_settings', JSON.stringify(state.settings));
    const chip = q('#modelChip');
    if (chip) chip.textContent = p.label + ' · ' + p.model;
    updateKeyStatus();
    const selected = q('#panelProvider');
    if (selected) selected.value = id;
    const model = q('#panelModel');
    if (model) model.value = p.model;
    refreshStatus('Modelo activado: ' + p.name);
  }

  async function testProfile(id) {
    const p = PROVIDERS[id];
    if (!p) throw new Error('Perfil no encontrado.');
    if (!isAndroid) throw new Error('La conexión se prueba desde la aplicación Android.');
    if (!Android.hasApiKey(id)) throw new Error('Guarda primero la clave API de este perfil.');
    // A models GET is less expensive than sending prompts and works for most OpenAI-compatible APIs,
    // but some providers don't expose it, so failure here doesn't prove that chat is unavailable.
    const result = await nativeRequest(joinUrl(p.base, 'models'), 'GET', null, id, p.auth, {});
    if (!result.ok) throw new Error(extractApiError(result));
    refreshStatus('Conexión autorizada con ' + p.label + ' (endpoint /models).');
  }

  function handleClick(event) {
    const button = event.target.closest('button[data-api-action]');
    if (!button) return;
    const { apiAction: action, apiId: id } = button.dataset;
    if (!profiles.has(id)) return;
    try {
      if (action === 'save') {
        if (!isAndroid) throw new Error('El guardado seguro requiere la app Android.');
        const input = q('#v055Key_' + id);
        const key = input ? input.value.trim() : '';
        if (!key) throw new Error('Introduce una clave API antes de guardarla.');
        Android.saveApiKey(id, key);
        input.value = '';
        renderRows();
        updateKeyStatus();
        refreshStatus('Clave guardada en Android Keystore.');
      } else if (action === 'use') {
        selectProfile(id);
      } else if (action === 'test') {
        button.disabled = true;
        refreshStatus('Comprobando el proveedor…');
        testProfile(id).catch(error => refreshStatus(error.message, true)).finally(() => { button.disabled = false; });
      } else if (action === 'delete') {
        if (!confirm('¿Eliminar este perfil y su clave API guardada?')) return;
        if (isAndroid) Android.clearApiKey(id);
        profiles.delete(id);
        delete PROVIDERS[id];
        persist();
        if (state.settings.provider === id) {
          state.settings.provider = 'multiai';
          state.settings.baseUrl = '';
          state.settings.model = 'auto';
          localStorage.setItem('multiai_settings', JSON.stringify(state.settings));
          const chip = q('#modelChip');
          if (chip) chip.textContent = 'MultiAI Auto · auto';
        }
        renderRows();
        updateKeyStatus();
        refreshStatus('Perfil y clave eliminados.');
      }
    } catch (error) { refreshStatus(error.message, true); }
  }

  const beforeSettings = window.openSettingsPanel;
  if (typeof beforeSettings === 'function') {
    window.openSettingsPanel = function (kind) {
      beforeSettings(kind);
      if (kind !== 'providers') return;
      const panel = q('#settingsPanel');
      if (!panel) return;
      const card = document.createElement('div');
      card.id = 'v055ApiCard';
      card.className = 'panel-card';
      card.innerHTML = `<h3>Mis proveedores API</h3>
        <p style="font-size:13px;color:#bbb">Añade tantas conexiones HTTPS como necesites. Compatibles con /chat/completions (formato OpenAI). Las claves se guardan cifradas en Android, no en el historial ni en esta lista.</p>
        <label class="field"><span>Nombre del proveedor</span><input id="v055Name" maxlength="60" placeholder="Mi proveedor"></label>
        <label class="field"><span>URL base HTTPS</span><input id="v055Base" placeholder="https://api.ejemplo.com/v1" autocapitalize="off"></label>
        <label class="field"><span>Identificador del modelo</span><input id="v055Model" placeholder="modelo-del-proveedor" autocapitalize="off"></label>
        <label class="field"><span>Autenticación</span><select id="v055Auth">
          <option value="bearer">Authorization: Bearer</option><option value="x-api-key">x-api-key</option>
          <option value="api-key">api-key</option><option value="x-goog-api-key">x-goog-api-key</option>
        </select></label>
        <button type="button" class="primary" id="v055Create">Añadir proveedor</button>
        <div id="v055Profiles"></div><p id="v055Result" role="status" style="font-size:12px;color:#bbb"></p>`;
      panel.appendChild(card);
      renderRows();
      q('#v055Create').onclick = () => {
        try {
          const profile = validateProfile({ name:q('#v055Name').value, base:q('#v055Base').value, model:q('#v055Model').value, auth:q('#v055Auth').value });
          if (profiles.size >= 100) throw new Error('Máximo 100 perfiles por dispositivo.');
          const id = prefix + Date.now().toString(36) + Math.random().toString(36).slice(2, 12);
          register(id, profile);
          persist();
          renderRows();
          refreshStatus('Proveedor añadido. Guarda su clave y pulsa «Usar modelo».');
          q('#v055Name').value = q('#v055Base').value = q('#v055Model').value = '';
        } catch (error) { refreshStatus(error.message, true); }
      };
      card.addEventListener('click', handleClick);
      // The legacy screen also lists all entries from PROVIDERS, including custom profiles.
      // Avoid a confusing duplicate key field by removing those duplicates in the legacy list.
      panel.querySelectorAll('#panelProviderKeys .provider-key-row').forEach(row => {
        const input = row.querySelector('input[id^="panelKey_"]');
        if (input && profiles.has(input.id.slice('panelKey_'.length))) row.remove();
      });
    };
    try { openSettingsPanel = window.openSettingsPanel; } catch { /* some WebViews fix global bindings */ }
  }
  const previousClear = window.clearData;
  if (typeof previousClear === 'function') {
    window.clearData = function () {
      // The original clearData() already calls secureStore.clearAll and localStorage.clear.
      previousClear();
      if (!localStorage.getItem(STORAGE)) {
        for (const id of profiles.keys()) delete PROVIDERS[id];
        profiles.clear();
      }
    };
    try { clearData = window.clearData; } catch { /* existing handler remains functional */ }
  }
  window.addEventListener('load', () => {
    const version = q('#version');
    if (version) version.textContent = '0.5.6 alpha';
    syncActiveProfile();
    updateKeyStatus();
  });
})();
