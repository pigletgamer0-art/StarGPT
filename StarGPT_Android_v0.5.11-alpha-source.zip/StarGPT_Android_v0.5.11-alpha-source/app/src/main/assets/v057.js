// MultiAI 0.5.7: unique names/emails, explicit local/server registration, no offline fallback.
(() => {
  'use strict';
  const $ = selector => document.querySelector(selector);
  const INDEX = 'multiai_local_account_directory_v057';
  const OLD_DB = 'multiai_local_accounts_v2';
  const normalizedEmail = email => String(email || '').trim().toLowerCase();
  const normalizedName = name => String(name || '').trim().normalize('NFKC').toLocaleLowerCase('en-US');
  let busy = false;

  function getIndex() {
    try {
      const list = JSON.parse(localStorage.getItem(INDEX) || '[]');
      return Array.isArray(list) ? list : [];
    } catch { return []; }
  }
  function addToIndex(user) {
    if (!user || user.mode !== 'local' || !user.email || !user.name) return;
    const list = getIndex().filter(x => normalizedEmail(x.email) !== normalizedEmail(user.email));
    list.push({email:normalizedEmail(user.email),name:String(user.name).trim()});
    localStorage.setItem(INDEX, JSON.stringify(list));
  }
  function knownLocalAccounts() {
    let older = [];
    try {
      const records = JSON.parse(localStorage.getItem(OLD_DB) || '{}');
      older = Object.values(records).map(record => record?.user).filter(Boolean);
    } catch { /* Older data may have been cleared. */ }
    let current = null;
    try {current = getAccount();} catch { /* Not signed in. */ }
    return [...getIndex(),...older,current].filter(u => u?.mode === 'local' || (u?.email && u?.name && !u.mode));
  }
  function showError(message) {
    const error=$('#authError');
    if(error){error.textContent=message;error.setAttribute('role','alert');}
  }
  function messageFromResponse(response) {
    try {const body=JSON.parse(response.body || '{}'); return body.error || `Error ${response.status||'de conexión'}`;}
    catch {return response.error || `El servidor respondió con el error ${response.status || 'desconocido'}.`;}
  }
  function backendAddress() {return (typeof getBackendUrl==='function'?getBackendUrl():'').trim();}
  function validateServerAddress(url) {
    if(!/^https:\/\//i.test(url)) throw new Error('Para registrar cuentas en el servidor utiliza una URL HTTPS.');
    try {new URL(url);} catch {throw new Error('La dirección del servidor no es válida.');}
  }
  function checkLocalDuplicates(name,email) {
    const records=knownLocalAccounts();
    if (records.some(u => normalizedName(u.name) === normalizedName(name)))
      throw new Error('Este nombre de usuario ya está en uso en este dispositivo.');
    if (records.some(u => normalizedEmail(u.email) === normalizedEmail(email)))
      throw new Error('Ya existe una cuenta con este correo electrónico en este dispositivo.');
  }
  function setStatus() {
    const status=$('#v057ModeInfo');if(!status)return;
    status.textContent=backendAddress()
      ? 'Cuenta en servidor: se registrarán tu nombre, correo, contraseña protegida mediante hash y fecha de registro. Se comprobarán duplicados entre los usuarios de ese servidor.'
      : 'Cuenta local: el registro queda solo en este dispositivo. No comprueba nombres ni correos de otros teléfonos.';
  }
  function prepareForm(mode) {
    if(typeof showAuthForm==='function') showAuthForm(mode);
    window.authMode=mode;
    const name=$('#authName');
    if (name) name.placeholder='Nombre de usuario único';
    const checkbox=$('#v057ConsentWrap');
    if (checkbox) checkbox.style.display=mode==='register'?'block':'none';
    if ($('#v057Consent')) $('#v057Consent').checked=false;
    setStatus();
  }
  async function submit() {
    if(busy)return;
    const email=normalizedEmail($('#authEmail')?.value);
    const password=$('#authPassword')?.value||'';
    const name=String($('#authName')?.value || '').trim();
    const mode=window.authMode || 'login';
    const isRegister=mode==='register';
    if(!email||!password||(isRegister&&!name))return showError('Completa todos los campos.');
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length>254)
      return showError('Escribe un correo electrónico válido.');
    if(isRegister){
      if(name.length<3||name.length>30||/[\x00-\x1f\x7f]/.test(name))return showError('El nombre debe tener entre 3 y 30 caracteres.');
      if(password.length<8||password.length>256)return showError('La contraseña debe tener entre 8 y 256 caracteres.');
      if(!$('#v057Consent')?.checked)return showError('Lee y acepta la información sobre el registro de tu cuenta.');
    }
    const button=$('#authSubmitBtn');
    busy=true;if(button){button.disabled=true;button.textContent=isRegister?'Registrando…':'Iniciando sesión…';}
    showError('');
    try {
      const backend=backendAddress();
      let user, token='';
      if(backend){
        validateServerAddress(backend);
        // Important: never create a local account if a configured remote server fails.
        // Doing so would misleadingly bypass the server-wide uniqueness check.
        const response=await nativeRequest(joinUrl(backend,isRegister?'auth/register':'auth/login'),
          'POST',{name,email,password},'','none');
        if(!response.ok)throw new Error(messageFromResponse(response));
        const result=JSON.parse(response.body||'{}');
        if(!result?.user?.id||!result.token)throw new Error('El servidor devolvió una respuesta inválida.');
        user={...result.user,mode:'server'};token=result.token;
      } else {
        if(typeof Android==='undefined' || !Android.registerLocalAccount)
          throw new Error('Las cuentas locales requieren la aplicación Android.');
        if(isRegister){
          checkLocalDuplicates(name,email);
          // Existing native accounts without an index will still reject duplicate emails.
          // Do not fall back to unencrypted WebView storage if the native operation fails.
          user=JSON.parse(Android.registerLocalAccount(name,email,password));
        } else {
          user=JSON.parse(Android.loginLocalAccount(email,password));
        }
        if (!user?.id)throw new Error('No se pudo obtener el registro local.');
        user.mode='local';token='';
        addToIndex(user); // Index contains names/emails only; no passwords or API keys.
      }
      setAccount(user,token);
      if(!token)localStorage.removeItem('multiai_token');
      hideAuthForm();
      toast(isRegister?'Cuenta creada correctamente':'Sesión iniciada');
    } catch(error){
      showError(error?.message || 'No se pudo registrar la cuenta.');
    } finally {
      busy=false;if(button){button.disabled=false;button.textContent=isRegister?'Crear cuenta':'Iniciar sesión';}
    }
  }
  async function deleteOnlineAccount(){
    const backend=backendAddress();
    if(!backend || getAccount()?.mode!=='server')return toast('Esta opción solo corresponde a cuentas en un servidor configurado.',true);
    if(!confirm('¿Eliminar definitivamente tu cuenta de este servidor? Esta acción no se puede deshacer.'))return;
    try {
      validateServerAddress(backend);
      const token=localStorage.getItem('multiai_token')||'';
      const response=await nativeRequest(joinUrl(backend,'me'),'DELETE',null,'','none',
        {'Authorization':'Bearer '+token});
      if(!response.ok)throw new Error(messageFromResponse(response));
      localStorage.removeItem('multiai_token');
      logoutAccount();
      toast('Cuenta del servidor eliminada.');
    } catch(error){toast(error.message||'No se pudo eliminar la cuenta.',true);}
  }
  function installAuthUI(){
    const form=$('#authForm');if(!form)return;
    if(!$('#v057ModeInfo')){
      const status=document.createElement('p');status.id='v057ModeInfo';status.style.cssText='font-size:12px;text-align:left;color:#b5becd;margin:7px 0';
      form.insertBefore(status,$('#authSubmitBtn'));
      const checkbox=document.createElement('label');checkbox.id='v057ConsentWrap';checkbox.style.cssText='font-size:12px;color:#c6c6c6;line-height:1.4;display:none';
      const input=document.createElement('input');input.id='v057Consent';input.type='checkbox';input.style.cssText='width:auto;margin-right:8px';
      checkbox.append(input,document.createTextNode('Entiendo dónde se guardarán mis datos de cuenta y acepto crear la cuenta.'));
      form.insertBefore(checkbox,$('#authSubmitBtn'));
      const settings=document.createElement('details');settings.style.cssText='margin:6px 0;color:#b5becd;font-size:12px';
      settings.innerHTML='<summary>Conectar servidor para cuentas compartidas</summary><p>Sin servidor, las cuentas solo existen en este teléfono. Usa únicamente un servidor MultiAI de confianza con HTTPS.</p><input id="v057ServerUrl" type="url" placeholder="https://tu-servidor.example" autocomplete="off"><button id="v057SaveServer" type="button" class="auth-secondary">Guardar servidor</button><button id="v057LocalMode" type="button" class="auth-link">Usar cuentas locales</button>';
      form.insertBefore(settings,$('#authSubmitBtn'));
      $('#v057ServerUrl').value=backendAddress();
      $('#v057SaveServer').onclick=()=>{try{
        const value=$('#v057ServerUrl').value.trim().replace(/\/$/,'');validateServerAddress(value);
        localStorage.setItem('multiai_backend',value);setStatus();showError('Servidor guardado.');
      }catch(e){showError(e.message);}};
      $('#v057LocalMode').onclick=()=>{localStorage.removeItem('multiai_backend');$('#v057ServerUrl').value='';setStatus();showError('Modo local seleccionado.');};
    }
    $('#authCreateBtn').onclick=()=>prepareForm('register');
    $('#authLoginBtn').onclick=()=>prepareForm('login');
    $('#authSubmitBtn').onclick=submit;
    for(const input of form.querySelectorAll('input')){
      // Existing older versions also listen to Enter. Capture and stop propagation so
      // a single Enter never sends two registration requests.
      input.addEventListener('keydown',event=>{
        if(event.key!=='Enter')return;
        event.preventDefault();event.stopImmediatePropagation();submit();
      },true);
    }
    addToIndex(getAccount());
    setStatus();
  }
  // The older app binds with setTimeout(...,0) on load; install afterward to prevent old handlers overwriting us.
  if(document.readyState==='complete')setTimeout(installAuthUI,15);else window.addEventListener('load',()=>setTimeout(installAuthUI,15));
  const oldSettings=window.openSettingsPanel;
  if(typeof oldSettings==='function'){
    window.openSettingsPanel=function(kind){
      oldSettings(kind);
      if(kind==='security'){
        const panel=$('#settingsPanel');if(!panel)return;
        const note=document.createElement('div');note.className='panel-card';
        note.innerHTML='<h3>Datos de la cuenta</h3><p>Las cuentas locales permanecen en el teléfono. Una cuenta en un servidor guarda nombre, correo, fecha de registro y hash de contraseña en ese servidor. El historial del chat y las claves API no forman parte del registro de cuentas.</p><button id="v057DeleteServerAccount" class="danger" type="button">Eliminar mi cuenta del servidor</button>';
        panel.appendChild(note);
        const btn=$('#v057DeleteServerAccount');
        btn.style.display=getAccount()?.mode==='server'?'':'none';
        btn.onclick=deleteOnlineAccount;
      }
    };
    try {openSettingsPanel=window.openSettingsPanel;}catch{ /* depends on WebView script scoping */ }
  }
})();
