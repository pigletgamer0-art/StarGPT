/* MultiAI v0.5.10 — independent, local interactive experiences inspired by
   publicly documented UI features. Does not depend on Google or any closed ChatGPT UI. */
(() => {
  'use strict';
  const STORE='multiai_interactive_v0510_';
  const byId=id=>document.getElementById(id);
  const escapeText=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const key=()=>STORE+String((typeof getAccount==='function'&&getAccount()?.id)||'guest').replace(/[^a-zA-Z0-9_-]/g,'_');
  function read(){try{const d=JSON.parse(localStorage.getItem(key())||'{}');return {decks:Array.isArray(d.decks)?d.decks:[],charts:Array.isArray(d.charts)?d.charts:[]};}catch{return {decks:[],charts:[]};}}
  function persist(d){localStorage.setItem(key(),JSON.stringify({decks:d.decks.slice(-40),charts:d.charts.slice(-40)}));}
  const uid=()=>String(Date.now())+'_'+Math.random().toString(36).slice(2,9);
  function cardsFromJSON(raw){
    const source=String(raw||'').trim().replace(/^```(?:json)?\s*/i,'').replace(/\s*```$/,'');
    const start=source.indexOf('['),end=source.lastIndexOf(']');
    if(start<0||end<=start)throw Error('La IA no devolvió una lista JSON de tarjetas. Inténtalo nuevamente.');
    let data;try{data=JSON.parse(source.slice(start,end+1));}catch{throw Error('Las tarjetas generadas no tienen un formato JSON válido.');}
    if(!Array.isArray(data))throw Error('Se esperaba una lista de tarjetas.');
    const cards=data.slice(0,20).map(x=>({front:String(x?.front??x?.pregunta??'').trim().slice(0,500),back:String(x?.back??x?.respuesta??'').trim().slice(0,1200)})).filter(x=>x.front&&x.back);
    if(!cards.length)throw Error('La IA no generó preguntas y respuestas utilizables.');
    return cards;
  }
  function manualCards(raw){const lines=String(raw||'').split(/\r?\n/).map(s=>s.trim()).filter(Boolean);const cards=lines.slice(0,100).map(line=>{const i=line.indexOf('|');return i<1?null:{front:line.slice(0,i).trim().slice(0,500),back:line.slice(i+1).trim().slice(0,1200)};}).filter(x=>x&&x.front&&x.back);if(!cards.length)throw Error('Usa una pregunta y una respuesta por línea: Pregunta | Respuesta');return cards;}
  function parseChart(raw){
    const lines=String(raw||'').split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
    const values=[];
    for(const line of lines){const m=/^(.+?)[,;\t]\s*(-?\d+(?:[.,]\d+)?)\s*$/.exec(line);if(!m)continue;
      const name=m[1].trim().replace(/^"|"$/g,'').slice(0,45),value=Number(m[2].replace(',','.'));
      if(name&&Number.isFinite(value))values.push({name,value});if(values.length===20)break;
    }
    if(values.length<2)throw Error('Introduce al menos dos filas: Nombre;valor (una fila por línea).');
    return values;
  }
  // Pure helpers exported for deterministic local tests, not for remote requests.
  window.MultiAIInteractive={cardsFromJSON,manualCards,parseChart};
  const css=document.createElement('style');css.textContent=`
    .mai10-overlay{position:fixed;inset:0;z-index:8600;background:#08090cef;display:none;align-items:center;justify-content:center;padding:calc(12px + env(safe-area-inset-top)) 12px calc(12px + env(safe-area-inset-bottom))}
    .mai10-overlay.show{display:flex}.mai10-panel{width:min(650px,100%);max-height:100%;overflow:auto;background:#191b21;border:1px solid #41434c;border-radius:24px;padding:17px;box-shadow:0 20px 80px #000b;color:#f8f8fb}
    .mai10-head{display:flex;align-items:center;gap:10px;margin-bottom:12px}.mai10-head h2{margin:0;flex:1;font-size:21px}.mai10-x{border:1px solid #555;background:#292a30;border-radius:10px;padding:7px 12px}
    .mai10-panel textarea,.mai10-panel input{display:block;width:100%;border:1px solid #555;border-radius:12px;background:#101115;color:white;padding:11px;resize:vertical;min-height:45px;box-sizing:border-box;margin:9px 0}
    .mai10-panel button{cursor:pointer}.mai10-btn{background:#2d70d8;border:0;border-radius:12px;padding:11px;color:#fff;margin:4px 5px 4px 0}.mai10-btn:disabled{opacity:.5}.mai10-muted{color:#b6b8c5;font-size:13px;line-height:1.5}.mai10-item{display:block;width:100%;background:#252730;border:1px solid #41434c;padding:11px;text-align:left;border-radius:12px;margin:8px 0;color:white}
    .mai10-flash{min-height:175px;display:grid;place-items:center;text-align:center;width:100%;padding:24px;background:#25253a;border:1px solid #68618b;border-radius:16px;font-size:19px;line-height:1.4;white-space:pre-wrap;overflow-wrap:anywhere}
    .mai10-row{display:flex;flex-wrap:wrap;align-items:center;gap:7px}.mai10-plot{width:100%;height:auto;max-height:330px;background:#14151b;border-radius:14px;margin:10px 0}.mai10-error{color:#ffc0ca;min-height:16px;font-size:13px}
    .mai10-readout{padding:10px;background:#272936;border-radius:10px;min-height:38px}
  `;document.head.append(css);
  const overlay=document.createElement('div');overlay.id='mai10Overlay';overlay.className='mai10-overlay';overlay.setAttribute('role','dialog');overlay.setAttribute('aria-modal','true');overlay.setAttribute('aria-label','Herramientas interactivas');
  overlay.innerHTML='<div class="mai10-panel"><div class="mai10-head"><h2 id="mai10Title">Herramientas</h2><button type="button" class="mai10-x" id="mai10Close" aria-label="Cerrar">✕</button></div><div id="mai10Body"></div></div>';
  document.body.append(overlay);const body=byId('mai10Body');
  function element(tag,text,cls,parent){const e=document.createElement(tag);if(text!=null)e.textContent=text;if(cls)e.className=cls;if(parent)parent.append(e);return e;}
  function btn(text,fn,parent){const b=element('button',text,'mai10-btn',parent);b.type='button';b.onclick=fn;return b;}
  function error(text){byId('mai10Error').textContent=text||'';}
  function title(text){byId('mai10Title').textContent=text;}
  function open(kind){overlay.classList.add('show');if(kind==='cards')listDecks();else listCharts();}
  function close(){overlay.classList.remove('show');body.replaceChildren();}
  byId('mai10Close').onclick=close;overlay.onclick=e=>{if(e.target===overlay)close();};
  byId('interactiveFlashcards')?.addEventListener('click',()=>open('cards'));
  byId('interactiveCharts')?.addEventListener('click',()=>open('charts'));
  function listDecks(){title('Tarjetas interactivas');body.replaceChildren();const data=read();btn('＋ Crear tarjetas',createDeckForm,body);element('p','Guardadas solo en este dispositivo y separadas por cuenta MultiAI.','mai10-muted',body);
    if(!data.decks.length)element('p','Todavía no hay tarjetas. Puedes escribirlas o generarlas con tu proveedor de IA.','mai10-muted',body);
    [...data.decks].reverse().forEach(deck=>{const row=element('div',null,'mai10-row',body);const b=btn(deck.title+' · '+deck.cards.length+' tarjetas',()=>studyDeck(deck.id),row);b.style.flex='1';btn('Eliminar',()=>{if(!confirm('¿Eliminar estas tarjetas?'))return;const x=read();x.decks=x.decks.filter(d=>d.id!==deck.id);persist(x);listDecks();},row);});
  }
  function createDeckForm(){title('Crear tarjetas');body.replaceChildren();btn('← Mis tarjetas',listDecks,body);const name=element('input',null,'',body);name.placeholder='Título del conjunto';name.maxLength=70;
    const manual=element('textarea',null,'',body);manual.rows=5;manual.placeholder='Pregunta 1 | Respuesta 1\nPregunta 2 | Respuesta 2';
    btn('Guardar estas tarjetas',()=>{try{const deck={id:uid(),title:name.value.trim().slice(0,70)||'Tarjetas',cards:manualCards(manual.value),created:Date.now(),missed:[]};const x=read();x.decks.push(deck);persist(x);studyDeck(deck.id);}catch(e){error(e.message);}},body);
    element('p','O genera hasta 12 tarjetas con tu proveedor de IA configurado. La solicitud se envía al proveedor activo, no a Google por defecto.','mai10-muted',body);
    const topic=element('textarea',null,'',body);topic.rows=3;topic.maxLength=12000;topic.placeholder='Tema, texto o apuntes para convertir en tarjetas…';
    const create=btn('✦ Generar con IA',async()=>{
      if(!topic.value.trim())return error('Escribe un tema o pega tus apuntes.');
      if(typeof activeProviderReady==='function'&&!activeProviderReady())return error('Configura primero una clave API válida en Ajustes.');
      if(state.busy)return error('Espera a que termine la respuesta anterior.');
      create.disabled=true;create.textContent='Generando…';error('');const original=state.messages,oldAttach=state.attachments,web=state.webSearch;
      state.busy=true;
      try{
        state.messages=[{role:'user',text:'Crea de 5 a 12 tarjetas breves, fieles a los datos, sobre lo siguiente. Responde SOLO un arreglo JSON válido, sin markdown, con objetos {"front":"pregunta","back":"respuesta"}. No inventes datos que no estén en los apuntes cuando se adjunten. Texto:\n'+topic.value.slice(0,12000)}];
        state.attachments=[];state.webSearch=false;
        const answer=await callActiveProvider([]),cards=cardsFromJSON(answer);
        const x=read(),deck={id:uid(),title:name.value.trim().slice(0,70)||topic.value.trim().slice(0,65),cards,created:Date.now(),missed:[]};x.decks.push(deck);persist(x);studyDeck(deck.id);
      }catch(e){error(e.message||'No se pudieron crear las tarjetas.');}
      finally{state.messages=original;state.attachments=oldAttach;state.webSearch=web;state.busy=false;create.disabled=false;create.textContent='✦ Generar con IA';}
    },body);
    element('div','', 'mai10-error',body).id='mai10Error';
  }
  function studyDeck(id,subset){const deck=read().decks.find(x=>x.id===id);if(!deck)return listDecks();title(deck.title);body.replaceChildren();btn('← Mis tarjetas',listDecks,body);
    let order=Array.isArray(subset)&&subset.length?subset.slice():deck.cards.map((_,i)=>i);let position=0,flipped=false,missed=new Set();const progress=element('p',null,'mai10-muted',body),flash=element('button',null,'mai10-flash',body),label=element('p','Toca la tarjeta para ver la respuesta.','mai10-muted',body),tools=element('div',null,'mai10-row',body);
    const render=()=>{if(position>=order.length){flash.textContent='¡Sesión completada!';flash.disabled=true;label.textContent='Fallaste '+missed.size+' de '+order.length+'.';progress.textContent='Repaso completado';return;}const card=deck.cards[order[position]];progress.textContent='Tarjeta '+(position+1)+' / '+order.length;flash.textContent=flipped?card.back:card.front;label.textContent=flipped?'Respuesta. Marca si la recordaste.':'Pregunta. Tócala para revelar la respuesta.';};
    flash.onclick=()=>{if(position>=order.length)return;flipped=!flipped;render();};
    const good=btn('✓ Lo sabía',()=>mark(false),tools),bad=btn('✕ Repasar',()=>mark(true),tools);
    const shuffle=btn('Mezclar',()=>{for(let i=order.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[order[i],order[j]]=[order[j],order[i]];}position=0;flipped=false;missed.clear();flash.disabled=false;render();},tools);
    btn('Repetir falladas',()=>{if(!missed.size)return;const selected=[...missed];order=selected;position=0;flipped=false;missed.clear();flash.disabled=false;render();},tools);
    function mark(isMissed){if(position>=order.length)return;if(isMissed)missed.add(order[position]);position++;flipped=false;render();}render();
  }
  function listCharts(){title('Gráficos interactivos');body.replaceChildren();btn('＋ Crear gráfico',chartForm,body);element('p','Los gráficos se guardan localmente por cuenta. No requieren API.','mai10-muted',body);
    const x=read();if(!x.charts.length)element('p','Añade una tabla de dos columnas para comenzar.','mai10-muted',body);
    [...x.charts].reverse().forEach(chart=>{const row=element('div',null,'mai10-row',body);const b=btn(chart.title+' · '+chart.values.length+' datos',()=>showChart(chart.id),row);b.style.flex='1';btn('Eliminar',()=>{if(!confirm('¿Eliminar el gráfico?'))return;const x=read();x.charts=x.charts.filter(c=>c.id!==chart.id);persist(x);listCharts();},row);});
  }
  function chartForm(){title('Crear gráfico');body.replaceChildren();btn('← Gráficos',listCharts,body);const name=element('input',null,'',body);name.placeholder='Título del gráfico';name.maxLength=70;
    const input=element('textarea',null,'',body);input.rows=7;input.placeholder='Enero;10\nFebrero;16\nMarzo;8';
    element('p','Introduce de 2 a 20 filas, con Nombre;valor o Nombre,valor. Los datos no se envían a ninguna API.','mai10-muted',body);
    btn('Crear gráfico',()=>{try{const values=parseChart(input.value);const d=read(),chart={id:uid(),title:name.value.trim().slice(0,70)||'Gráfico',values,created:Date.now()};d.charts.push(chart);persist(d);showChart(chart.id);}catch(e){error(e.message);}},body);
    element('div','', 'mai10-error',body).id='mai10Error';
  }
  function showChart(id){const chart=read().charts.find(x=>x.id===id);if(!chart)return listCharts();title(chart.title);body.replaceChildren();btn('← Gráficos',listCharts,body);const controls=element('div',null,'mai10-row',body);let mode='bar',chosen=0;const plot=element('div',null,'',body),readout=element('div',null,'mai10-readout',body),options=element('div',null,'mai10-row',body);
    btn('Barras',()=>{mode='bar';paint();},controls);btn('Líneas',()=>{mode='line';paint();},controls);
    const values=chart.values;
    function paint(){
      const all=values.map(v=>v.value);const low=Math.min(0,...all),high=Math.max(0,...all);const range=(high-low)||1;
      const w=600,h=310,l=52,r=16,t=18,b=65,innerW=w-l-r,innerH=h-t-b,step=innerW/values.length;
      const y=v=>t+(high-v)/range*innerH;
      let svg='<svg class="mai10-plot" role="img" aria-label="'+escapeText(chart.title)+'" viewBox="0 0 600 310" xmlns="http://www.w3.org/2000/svg">';
      for(let k=0;k<=4;k++){const yy=t+(innerH*k/4),n=high-range*k/4;svg+='<line x1="'+l+'" y1="'+yy+'" x2="'+(w-r)+'" y2="'+yy+'" stroke="#454755"/><text x="'+(l-7)+'" y="'+(yy+4)+'" text-anchor="end" font-size="11" fill="#d6d7e0">'+Number(n.toFixed(2))+'</text>';}
      if(mode==='bar')values.forEach((v,i)=>{const cx=l+step*(i+.5),top=Math.min(y(v.value),y(0)),height=Math.max(1,Math.abs(y(v.value)-y(0)));svg+='<rect x="'+(cx-step*.32)+'" y="'+top+'" width="'+step*.64+'" height="'+height+'" rx="3" fill="'+(i===chosen?'#a9e3ff':'#749cf2')+'"/>';});
      else {const pts=values.map((v,i)=>(l+step*(i+.5))+','+y(v.value)).join(' ');svg+='<polyline points="'+pts+'" fill="none" stroke="#91b3ff" stroke-width="3"/>';values.forEach((v,i)=>svg+='<circle cx="'+(l+step*(i+.5))+'" cy="'+y(v.value)+'" r="'+(i===chosen?7:4)+'" fill="'+(i===chosen?'#a9e3ff':'#91b3ff')+'"/>');}
      values.forEach((v,i)=>{const cx=l+step*(i+.5);svg+='<text x="'+cx+'" y="'+(h-b+14)+'" text-anchor="end" transform="rotate(-35 '+cx+' '+(h-b+14)+')" font-size="10" fill="#e1e1e8">'+escapeText(v.name.slice(0,13))+'</text>';});
      plot.innerHTML=svg+'</svg>';readout.textContent=values[chosen].name+': '+values[chosen].value;
      options.replaceChildren();values.forEach((v,i)=>{const b=btn(v.name,()=>{chosen=i;paint();},options);b.setAttribute('aria-pressed',String(chosen===i));if(chosen===i)b.style.background='#5940a5';});
    }paint();
  }
})();
