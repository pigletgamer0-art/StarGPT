package com.multiai.assistant

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.io.BufferedReader
import java.io.ByteArrayOutputStream
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import java.security.MessageDigest
import java.util.Locale
import java.util.UUID
import java.util.concurrent.Executors
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var webView: WebView
    private lateinit var bridge: AndroidBridge
    private var tts: TextToSpeech? = null
    private lateinit var googleSignInClient: GoogleSignInClient
    private val worker = Executors.newCachedThreadPool()

    companion object {
        private const val PICK_FILE_REQUEST = 2001
        private const val SPEECH_REQUEST = 2002
        private const val GOOGLE_SIGN_IN_REQUEST = 2003
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tts = TextToSpeech(this, this)
        // OAuth web client ID must match GOOGLE_WEB_CLIENT_ID on the StarGPT server.
        val googleOptions = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .apply { if (BuildConfig.GOOGLE_WEB_CLIENT_ID.isNotBlank()) requestIdToken(BuildConfig.GOOGLE_WEB_CLIENT_ID) }
            .build()
        googleSignInClient = GoogleSignIn.getClient(this, googleOptions)
        webView = findViewById(R.id.webView)
        bridge = AndroidBridge()

        webView.setBackgroundColor(Color.rgb(10, 11, 14))
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            cacheMode = WebSettings.LOAD_DEFAULT
            mediaPlaybackRequiresUserGesture = false
        }
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                return if (uri.scheme == "http" || uri.scheme == "https") {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                    true
                } else false
            }
        }
        webView.addJavascriptInterface(bridge, "Android")
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        worker.shutdownNow()
        webView.removeJavascriptInterface("Android")
        webView.destroy()
        super.onDestroy()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.getDefault()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_FILE_REQUEST && resultCode == Activity.RESULT_OK) {
            val uri = data?.data ?: return
            worker.execute { deliverPickedFile(uri) }
        } else if (requestCode == SPEECH_REQUEST && resultCode == Activity.RESULT_OK) {
            val text = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            callback("window.NativeBridgeCallbacks.onVoiceResult", JSONObject.quote(text))
        } else if (requestCode == GOOGLE_SIGN_IN_REQUEST) {
            try {
                val account = GoogleSignIn.getSignedInAccountFromIntent(data).getResult(ApiException::class.java)
                val obj = JSONObject()
                    .put("ok", true)
                    // Do not trust profile email/name from the phone: verify ID token on server.
                    .put("idToken", account.idToken ?: "")
                callback("window.NativeBridgeCallbacks.onGoogleSignIn", obj.toString())
            } catch (e: Exception) {
                val obj = JSONObject().put("ok", false).put("error", e.message ?: "No se pudo iniciar sesión con Google")
                callback("window.NativeBridgeCallbacks.onGoogleSignIn", obj.toString())
            }
        }
    }

    private fun deliverPickedFile(uri: Uri) {
        try {
            val mime = contentResolver.getType(uri) ?: "application/octet-stream"
            var name = "archivo"
            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && cursor.moveToFirst()) name = cursor.getString(idx)
            }
            val bytes = contentResolver.openInputStream(uri)?.use { input ->
                val out = ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                var total = 0
                while (true) {
                    val n = input.read(buffer)
                    if (n <= 0) break
                    total += n
                    if (total > 12 * 1024 * 1024) throw IllegalArgumentException("El archivo supera el límite de 12 MB.")
                    out.write(buffer, 0, n)
                }
                out.toByteArray()
            } ?: throw IllegalStateException("No se pudo leer el archivo.")

            val obj = JSONObject().put("name", name).put("mime", mime).put("size", bytes.size)
            if (mime.startsWith("image/")) {
                obj.put("kind", "image")
                obj.put("base64", Base64.encodeToString(bytes, Base64.NO_WRAP))
            } else if (mime.startsWith("text/") || name.matches(Regex(".*\\.(txt|md|json|csv|js|ts|html|css|py|kt|java|lua|luau|xml|yaml|yml)$", RegexOption.IGNORE_CASE))) {
                obj.put("kind", "text")
                obj.put("text", String(bytes, StandardCharsets.UTF_8))
            } else {
                obj.put("kind", "binary")
                obj.put("base64", Base64.encodeToString(bytes, Base64.NO_WRAP))
            }
            callback("window.NativeBridgeCallbacks.onPickedFile", obj.toString())
        } catch (e: Exception) {
            callback("window.NativeBridgeCallbacks.onError", JSONObject.quote(e.message ?: "Error al abrir archivo"))
        }
    }

    private fun callback(function: String, argExpression: String) {
        runOnUiThread { webView.evaluateJavascript("$function($argExpression);", null) }
    }

    inner class AndroidBridge {
        private val secureStore = SecureStore(this@MainActivity)

        @JavascriptInterface
        fun appVersion(): String = BuildConfig.VERSION_NAME

        @JavascriptInterface
        fun startGoogleSignIn() {
            runOnUiThread {
                try {
                    if (BuildConfig.GOOGLE_WEB_CLIENT_ID.isBlank()) {
                        val obj = JSONObject().put("ok", false).put("error", "Configura el OAuth Web Client ID al compilar StarGPT.")
                        callback("window.NativeBridgeCallbacks.onGoogleSignIn", obj.toString())
                        return@runOnUiThread
                    }
                    startActivityForResult(googleSignInClient.signInIntent, GOOGLE_SIGN_IN_REQUEST)
                } catch (e: Exception) {
                    val obj = JSONObject().put("ok", false).put("error", e.message ?: "No se pudo abrir Google Sign-In")
                    callback("window.NativeBridgeCallbacks.onGoogleSignIn", obj.toString())
                }
            }
        }

        private fun normalizeEmail(email: String): String = email.trim().lowercase(Locale.ROOT)

        private fun passwordHash(email: String, password: String): String {
            val digest = MessageDigest.getInstance("SHA-256")
            val bytes = digest.digest((normalizeEmail(email) + "|StarGPT|" + password).toByteArray(StandardCharsets.UTF_8))
            return bytes.joinToString("") { "%02x".format(it) }
        }

        @JavascriptInterface
        fun registerLocalAccount(name: String, email: String, password: String): String {
            val normalized = normalizeEmail(email)
            require(name.trim().isNotBlank()) { "Escribe tu nombre." }
            require(normalized.contains("@")) { "Correo no válido." }
            require(password.length >= 6) { "La contraseña debe tener al menos 6 caracteres." }
            val slot = "localAccount:$normalized"
            require(secureStore.get(slot).isBlank()) { "Ya existe una cuenta con ese correo en este dispositivo." }
            val obj = JSONObject()
                .put("id", "local-" + UUID.randomUUID().toString())
                .put("mode", "local")
                .put("name", name.trim())
                .put("email", normalized)
                .put("plan", "free")
                .put("passwordHash", passwordHash(normalized, password))
            secureStore.put(slot, obj.toString())
            obj.remove("passwordHash")
            return obj.toString()
        }

        @JavascriptInterface
        fun loginLocalAccount(email: String, password: String): String {
            val normalized = normalizeEmail(email)
            val raw = secureStore.get("localAccount:$normalized")
            require(raw.isNotBlank()) { "No existe una cuenta con ese correo en este dispositivo." }
            val obj = JSONObject(raw)
            require(obj.optString("passwordHash") == passwordHash(normalized, password)) { "Contraseña incorrecta." }
            obj.remove("passwordHash")
            return obj.toString()
        }


        private fun keySlot(provider: String): String = "apiKey:${provider.trim().lowercase(Locale.ROOT)}"

        private fun providerKey(provider: String): String {
            val id = provider.trim().lowercase(Locale.ROOT).ifBlank { "openai" }
            val modern = secureStore.get(keySlot(id))
            if (modern.isNotBlank()) return modern
            // Migration path from StarGPT v0.1/v0.2, which stored a single OpenAI key.
            if (id == "openai") return secureStore.get("apiKey")
            return ""
        }

        @JavascriptInterface
        fun hasApiKey(provider: String): Boolean = providerKey(provider).isNotBlank()

        @JavascriptInterface
        fun saveApiKey(provider: String, value: String) {
            secureStore.put(keySlot(provider), value.trim())
            if (provider.equals("openai", ignoreCase = true)) secureStore.remove("apiKey")
        }

        @JavascriptInterface
        fun clearApiKey(provider: String) {
            secureStore.remove(keySlot(provider))
            if (provider.equals("openai", ignoreCase = true)) secureStore.remove("apiKey")
        }

        @JavascriptInterface
        fun clearAllApiKeys() {
            secureStore.clearAll()
        }

        @JavascriptInterface
        fun request(id: String, url: String, method: String, headersJson: String, body: String, keyId: String, authMode: String) {
            worker.execute {
                val result = JSONObject().put("id", id)
                try {
                    val parsed = URL(url)
                    require(parsed.protocol == "https" || parsed.protocol == "http") { "Solo se permiten URLs HTTP/HTTPS." }
                    val conn = parsed.openConnection() as HttpURLConnection
                    conn.requestMethod = method.uppercase(Locale.ROOT)
                    conn.connectTimeout = 30_000
                    conn.readTimeout = 180_000
                    conn.setRequestProperty("Accept", "application/json")
                    conn.setRequestProperty("User-Agent", "StarGPT-Android/${BuildConfig.VERSION_NAME}")
                    if (headersJson.isNotBlank()) {
                        val headers = JSONObject(headersJson)
                        for (key in headers.keys()) conn.setRequestProperty(key, headers.optString(key))
                    }
                    if (authMode.isNotBlank() && !authMode.equals("none", ignoreCase = true)) {
                        val key = providerKey(keyId)
                        require(key.isNotBlank()) { "Falta la API key de $keyId. Agrégala en Ajustes." }
                        when (authMode.lowercase(Locale.ROOT)) {
                            "bearer" -> conn.setRequestProperty("Authorization", "Bearer $key")
                            "x-api-key" -> conn.setRequestProperty("x-api-key", key)
                            "x-goog-api-key" -> conn.setRequestProperty("x-goog-api-key", key)
                            "api-key" -> conn.setRequestProperty("api-key", key)
                            else -> conn.setRequestProperty("Authorization", "Bearer $key")
                        }
                    }
                    if (body.isNotEmpty() && method.uppercase(Locale.ROOT) != "GET") {
                        conn.doOutput = true
                        if (conn.getRequestProperty("Content-Type").isNullOrBlank()) conn.setRequestProperty("Content-Type", "application/json")
                        conn.outputStream.use { it.write(body.toByteArray(StandardCharsets.UTF_8)) }
                    }
                    val status = conn.responseCode
                    val stream = if (status in 200..299) conn.inputStream else conn.errorStream
                    val responseText = stream?.use { s -> BufferedReader(InputStreamReader(s, StandardCharsets.UTF_8)).readText() }.orEmpty()
                    result.put("ok", status in 200..299).put("status", status).put("body", responseText)
                    conn.disconnect()
                } catch (e: Exception) {
                    result.put("ok", false).put("status", 0).put("error", e.message ?: e.javaClass.simpleName)
                }
                callback("window.NativeBridgeCallbacks.onRequestResult", result.toString())
            }
        }

        @JavascriptInterface
        fun fetchBinary(id: String, url: String) {
            worker.execute {
                val result = JSONObject().put("id", id)
                try {
                    val conn = URL(url).openConnection() as HttpURLConnection
                    conn.connectTimeout = 30_000
                    conn.readTimeout = 120_000
                    conn.setRequestProperty("User-Agent", "StarGPT-Android/${BuildConfig.VERSION_NAME}")
                    val status = conn.responseCode
                    if (status !in 200..299) throw IllegalStateException("HTTP $status")
                    val mime = conn.contentType ?: "application/octet-stream"
                    val bytes = conn.inputStream.use { it.readBytes() }
                    result.put("ok", true).put("mime", mime).put("base64", Base64.encodeToString(bytes, Base64.NO_WRAP))
                    conn.disconnect()
                } catch (e: Exception) {
                    result.put("ok", false).put("error", e.message ?: "No se pudo descargar")
                }
                callback("window.NativeBridgeCallbacks.onBinaryResult", result.toString())
            }
        }

        @JavascriptInterface
        fun saveTextFile(name: String, mime: String, content: String): String {
            return try {
                saveToDownloads(name, mime.ifBlank { "text/plain" }, content.toByteArray(StandardCharsets.UTF_8)).toString()
            } catch (e: Exception) {
                "ERROR:${e.message}"
            }
        }

        @JavascriptInterface
        fun saveBase64File(name: String, mime: String, base64: String): String {
            return try {
                val clean = base64.substringAfter("base64,", base64)
                val bytes = Base64.decode(clean, Base64.DEFAULT)
                saveToDownloads(name, mime.ifBlank { "application/octet-stream" }, bytes).toString()
            } catch (e: Exception) {
                "ERROR:${e.message}"
            }
        }

        @JavascriptInterface
        fun pickFile(accept: String) {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = if (accept.isBlank() || accept == "*/*") "*/*" else accept
                }
                startActivityForResult(intent, PICK_FILE_REQUEST)
            }
        }

        @JavascriptInterface
        fun startVoiceInput() {
            runOnUiThread {
                try {
                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
                        putExtra(RecognizerIntent.EXTRA_PROMPT, "Habla con StarGPT")
                    }
                    startActivityForResult(intent, SPEECH_REQUEST)
                } catch (_: Exception) {
                    Toast.makeText(this@MainActivity, "No hay reconocimiento de voz disponible.", Toast.LENGTH_SHORT).show()
                }
            }
        }

        @JavascriptInterface
        fun speak(text: String) {
            runOnUiThread {
                tts?.speak(text.take(5000), TextToSpeech.QUEUE_FLUSH, null, UUID.randomUUID().toString())
            }
        }

        @JavascriptInterface
        fun shareText(title: String, text: String) {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, title)
                    putExtra(Intent.EXTRA_TEXT, text)
                }
                startActivity(Intent.createChooser(intent, "Compartir"))
            }
        }

        @JavascriptInterface
        fun openUrl(url: String) {
            runOnUiThread {
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) {}
            }
        }
    }

    private fun saveToDownloads(nameRaw: String, mime: String, bytes: ByteArray): Uri {
        val name = sanitizeFileName(nameRaw.ifBlank { "archivo_${System.currentTimeMillis()}" })
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, "Download/StarGPT")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("No se pudo crear el archivo.")
        try {
            contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                ?: throw IllegalStateException("No se pudo escribir el archivo.")
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
            runOnUiThread { Toast.makeText(this, "Guardado en Descargas/StarGPT", Toast.LENGTH_SHORT).show() }
            return uri
        } catch (e: Exception) {
            contentResolver.delete(uri, null, null)
            throw e
        }
    }

    private fun sanitizeFileName(name: String): String = name.replace(Regex("[\\\\/:*?\"<>|]"), "_").take(120)
}

private class SecureStore(private val activity: Activity) {
    private val prefs = activity.getSharedPreferences("secure_store", Activity.MODE_PRIVATE)
    private val alias = "StarGPTKey"

    fun put(key: String, value: String) {
        if (value.isBlank()) { remove(key); return }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val encrypted = cipher.doFinal(value.toByteArray(StandardCharsets.UTF_8))
        val payload = Base64.encodeToString(cipher.iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(encrypted, Base64.NO_WRAP)
        prefs.edit().putString(key, payload).apply()
    }

    fun get(key: String): String {
        val payload = prefs.getString(key, null) ?: return ""
        return try {
            val parts = payload.split(":", limit = 2)
            if (parts.size != 2) return ""
            val iv = Base64.decode(parts[0], Base64.DEFAULT)
            val encrypted = Base64.decode(parts[1], Base64.DEFAULT)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(encrypted), StandardCharsets.UTF_8)
        } catch (_: Exception) { "" }
    }

    fun remove(key: String) { prefs.edit().remove(key).apply() }

    fun clearAll() { prefs.edit().clear().apply() }

    private fun getOrCreateKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(alias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance("AES", "AndroidKeyStore")
        val spec = android.security.keystore.KeyGenParameterSpec.Builder(
            alias,
            android.security.keystore.KeyProperties.PURPOSE_ENCRYPT or android.security.keystore.KeyProperties.PURPOSE_DECRYPT
        ).setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        generator.init(spec)
        return generator.generateKey()
    }
}
