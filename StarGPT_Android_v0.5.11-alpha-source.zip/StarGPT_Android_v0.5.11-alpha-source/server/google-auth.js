// Verify Google ID tokens server-side. Never identify an account from client-supplied email/id.
import crypto from 'node:crypto';
const JWKS_ENDPOINT='https://www.googleapis.com/oauth2/v3/certs';
let cache={keys:[],expires:0};
export async function verifyGoogleIdToken(token, clientId, getKeys=async()=>{
  if(Date.now()<cache.expires && cache.keys.length)return cache.keys;
  const response=await fetch(JWKS_ENDPOINT,{signal:AbortSignal.timeout(6000)});
  if(!response.ok)throw new Error('No se pudieron verificar las claves públicas de Google.');
  const doc=await response.json();if(!Array.isArray(doc.keys)||!doc.keys.length)throw new Error('Claves públicas de Google no disponibles.');
  const age=Number(/max-age=(\d+)/i.exec(response.headers.get('cache-control')||'')?.[1]||300);
  cache={keys:doc.keys,expires:Date.now()+Math.min(Math.max(age,60),3600)*1000};return cache.keys;
}){
  if(!clientId)throw new Error('GOOGLE_WEB_CLIENT_ID no está configurado en el servidor.');
  if(typeof token!=='string'||token.length>16000||token.length<50)throw new Error('Token de Google inválido.');
  const sections=token.split('.');if(sections.length!==3)throw new Error('Token de Google inválido.');
  const header=JSON.parse(Buffer.from(sections[0],'base64url').toString('utf8'));
  if(header.alg!=='RS256'||typeof header.kid!=='string')throw new Error('Algoritmo de token no admitido.');
  const keys=await getKeys();const jwk=keys.find(k=>k.kid===header.kid&&k.kty==='RSA'&&(!k.alg||k.alg==='RS256')&&(!k.use||k.use==='sig'));
  if(!jwk)throw new Error('No se encuentra la clave de firma de Google.');
  const key=crypto.createPublicKey({key:jwk,format:'jwk'});
  const valid=crypto.verify('RSA-SHA256',Buffer.from(sections[0]+'.'+sections[1]),key,Buffer.from(sections[2],'base64url'));
  if(!valid)throw new Error('Firma de Google inválida.');
  const p=JSON.parse(Buffer.from(sections[1],'base64url').toString('utf8'));const now=Math.floor(Date.now()/1000);
  if(p.aud!==clientId||!['accounts.google.com','https://accounts.google.com'].includes(p.iss)||
     !Number.isInteger(p.exp)||p.exp<=now||!Number.isInteger(p.iat)||p.iat>now+60||
     (p.nbf && p.nbf>now+60)||typeof p.sub!=='string'||!p.sub||
     typeof p.email!=='string'||p.email_verified!==true)
    throw new Error('Token de Google caducado, no verificado o emitido para otra aplicación.');
  return {sub:p.sub,email:p.email.trim().toLowerCase(),name:String(p.name||'').slice(0,90)};
}
