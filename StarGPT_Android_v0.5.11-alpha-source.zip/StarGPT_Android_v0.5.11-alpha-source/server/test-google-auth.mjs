import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {verifyGoogleIdToken} from './google-auth.js';
const {publicKey,privateKey}=crypto.generateKeyPairSync('rsa',{modulusLength:2048});
const pub=publicKey.export({format:'jwk'});Object.assign(pub,{kid:'test-key',alg:'RS256',use:'sig'});
const audience='multiai-test.apps.googleusercontent.com';
const now=Math.floor(Date.now()/1000);
function makeToken(p){const h=Buffer.from(JSON.stringify({alg:'RS256',kid:'test-key'})).toString('base64url');const b=Buffer.from(JSON.stringify(p)).toString('base64url');const sig=crypto.sign('RSA-SHA256',Buffer.from(h+'.'+b),privateKey).toString('base64url');return h+'.'+b+'.'+sig;}
const payload={iss:'https://accounts.google.com',aud:audience,sub:'google-test-sub',email:'USER@EXAMPLE.COM',email_verified:true,iat:now-1,exp:now+1800};
const keys=async()=>[pub];
const verified=await verifyGoogleIdToken(makeToken(payload),audience,keys);
assert.equal(verified.sub,'google-test-sub');assert.equal(verified.email,'user@example.com');
for(const change of [{aud:'other-client'}, {email_verified:false}, {exp:now-2},{iss:'https://untrusted.com'}, {sub:''}]){
  await assert.rejects(verifyGoogleIdToken(makeToken({...payload,...change}),audience,keys));
}
const forged=makeToken(payload).replace(/.$/,v=>v==='a'?'b':'a');
await assert.rejects(verifyGoogleIdToken(forged,audience,keys));
console.log('PASS: valid Google JWT + rejects wrong audience, unverified email, expired token, wrong issuer, missing sub, tampered signature');
