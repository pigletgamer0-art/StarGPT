// MultiAI v0.5.7 account service. Configure HTTPS reverse proxy, persistence and TOKEN_SECRET before deployment.
import http from 'node:http';
import crypto from 'node:crypto';
import {verifyGoogleIdToken} from './google-auth.js';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 8787);
const DB_PATH = process.env.MULTIAI_DB || path.join(__dirname, 'data.json');
const OLLAMA_URL = (process.env.OLLAMA_URL || 'http://127.0.0.1:11434').replace(/\/$/, '');
const TOKEN_SECRET = process.env.TOKEN_SECRET || '';
const GOOGLE_WEB_CLIENT_ID = process.env.GOOGLE_WEB_CLIENT_ID || ''; 
const DEFAULT_OLLAMA_MODEL = process.env.OLLAMA_MODEL || 'qwen3:1.7b';
if (TOKEN_SECRET.length < 32) throw new Error('TOKEN_SECRET debe tener al menos 32 caracteres aleatorios.');
const normalizeName = value => String(value || '').trim().normalize('NFKC').toLocaleLowerCase('en-US');
const normalizeEmail = value => String(value || '').trim().toLowerCase();
const publicUser = u => ({id:u.id,mode:'server',name:u.name,email:u.email,plan:u.plan,founderNumber:u.founderNumber || null,createdAt:u.createdAt});

function loadDb() {
  try {
    const db = JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
    if (!Array.isArray(db.users)) throw new Error('Base de datos inválida');
    return db;
  } catch (e) {
    if (e.code === 'ENOENT') return {users:[],nextFounder:1};
    throw e; // Never reset an invalid/corrupted DB: could silently allow duplicates.
  }
}
function saveDb(db) {
  fs.mkdirSync(path.dirname(DB_PATH), {recursive:true,mode:0o700});
  const tmp = DB_PATH + '.' + process.pid + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2), {mode:0o600});
  fs.renameSync(tmp, DB_PATH);
}
function json(res, status, value) {
  res.writeHead(status, {'content-type':'application/json; charset=utf-8','cache-control':'no-store',
    'x-content-type-options':'nosniff'});
  res.end(JSON.stringify(value));
}
function readBody(req) {
  return new Promise((resolve,reject) => {
    let data = '', size = 0;
    req.on('data', chunk => {
      size += chunk.length;
      if (size > (req.url === '/v1/chat' ? 2_000_000 : 32_768)) { reject(Object.assign(new Error('Solicitud demasiado grande'), {status:413})); req.destroy(); return; }
      data += chunk;
    });
    req.on('end', () => {try {resolve(JSON.parse(data || '{}'));} catch {reject(Object.assign(new Error('JSON inválido'), {status:400}));}});
    req.on('error', reject);
  });
}
function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  return {salt,hash:crypto.scryptSync(password,salt,64).toString('hex')};
}
function verifyPassword(password,user) {
  try {
    const actual = Buffer.from(user.passwordHash,'hex');
    const attempt = crypto.scryptSync(password,user.passwordSalt,actual.length);
    return actual.length === attempt.length && crypto.timingSafeEqual(actual,attempt);
  } catch {return false;}
}
function sign(payload) {
  const encoded = Buffer.from(JSON.stringify(payload)).toString('base64url');
  return encoded + '.' + crypto.createHmac('sha256',TOKEN_SECRET).update(encoded).digest('base64url');
}
function verify(token) {
  try {
    const [encoded, signature] = token.split('.');
    const expected = crypto.createHmac('sha256',TOKEN_SECRET).update(encoded).digest('base64url');
    const actual = Buffer.from(signature || '','utf8'), wanted = Buffer.from(expected,'utf8');
    if (actual.length !== wanted.length || !crypto.timingSafeEqual(actual,wanted)) return null;
    const payload = JSON.parse(Buffer.from(encoded,'base64url').toString('utf8'));
    return payload.exp > Date.now() ? payload : null;
  } catch {return null;}
}
const tokenFor = u => sign({uid:u.id,exp:Date.now()+1000*60*60*24*7});
const authorizedUser = req => {
  const payload = verify((req.headers.authorization || '').replace(/^Bearer\s+/i,''));
  return payload ? loadDb().users.find(u=>u.id === payload.uid) : null;
};
const server = http.createServer(async (req,res) => {
  // Do not log emails, names, passwords, tokens or request bodies.
  try {
    if (req.method === 'GET' && req.url === '/health') return json(res,200,{ok:true,version:'0.5.9'});
    // A verified Google ID token is required for both lookup and registration.
    if(req.method==='POST' && (req.url==='/auth/google/lookup' || req.url==='/auth/google/register')){
      if(!GOOGLE_WEB_CLIENT_ID) return json(res,503,{error:'Google no está configurado en este servidor.'});
      const {idToken,name}=await readBody(req);
      let google;
      try{google=await verifyGoogleIdToken(idToken,GOOGLE_WEB_CLIENT_ID);}
      catch(e){return json(res,401,{error:'No se pudo verificar la identidad con Google. Vuelve a iniciar sesión.'});}
      const db=loadDb();
      const previous=db.users.find(u=>u.googleSub===google.sub);
      if(previous){
        // A stable Google subject, never an email entered by the user, identifies the account.
        return json(res,200,{user:publicUser(previous),token:tokenFor(previous),isNew:false});
      }
      const emailUser=db.users.find(u=>normalizeEmail(u.email)===google.email);
      if(emailUser)return json(res,409,{error:'Este correo ya está registrado con otro método. Inicia sesión con ese método; la vinculación requiere verificar ambas cuentas.',code:'EMAIL_EXISTS_DIFFERENT_METHOD'});
      if(req.url==='/auth/google/lookup')return json(res,200,{needsName:true,googleName:google.name});
      const displayName=String(name||'').trim();
      if(displayName.length<3||displayName.length>30||/[\x00-\x1f\x7f]/.test(displayName))
        return json(res,400,{error:'El nombre debe tener entre 3 y 30 caracteres.'});
      if(db.users.some(u=>normalizeName(u.name)===normalizeName(displayName)))
        return json(res,409,{error:'Este nombre de usuario ya está en uso.',code:'USERNAME_TAKEN'});
      const founderNumber=db.nextFounder<=20?db.nextFounder++:null;
      const user={id:crypto.randomUUID(),name:displayName,email:google.email,googleSub:google.sub,
        plan:founderNumber?'plus':'free',founderNumber,createdAt:Date.now()};
      db.users.push(user);saveDb(db);
      return json(res,201,{user:publicUser(user),token:tokenFor(user),isNew:true});
    }
    if (req.method === 'POST' && req.url === '/auth/register') {
      const {name,email,password} = await readBody(req);
      const displayName=String(name||'').trim(), normalizedName=normalizeName(name), normalizedEmail=normalizeEmail(email);
      if (displayName.length < 3 || displayName.length > 30 || /[\x00-\x1f\x7f]/.test(displayName))
        return json(res,400,{error:'El nombre de usuario debe tener entre 3 y 30 caracteres.'});
      if (normalizedEmail.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizedEmail))
        return json(res,400,{error:'Escribe un correo electrónico válido.'});
      if (typeof password !== 'string' || password.length < 8 || password.length > 256)
        return json(res,400,{error:'La contraseña debe tener entre 8 y 256 caracteres.'});
      // This synchronous transaction has a single writer in one Node process; run ONE server process
      // against this file. For multiple instances, replace JSON storage with a SQL database and UNIQUE indexes.
      const db=loadDb();
      if (db.users.some(u=>normalizeName(u.name) === normalizedName))
        return json(res,409,{error:'Este nombre de usuario ya está en uso.',code:'USERNAME_TAKEN'});
      if (db.users.some(u=>normalizeEmail(u.email) === normalizedEmail))
        return json(res,409,{error:'Ya existe una cuenta con este correo electrónico.',code:'EMAIL_TAKEN'});
      const pw=hashPassword(password);
      const founderNumber = db.nextFounder <= 20 ? db.nextFounder++ : null;
      const user={id:crypto.randomUUID(),name:displayName,email:normalizedEmail,passwordSalt:pw.salt,
        passwordHash:pw.hash,plan:founderNumber?'plus':'free',founderNumber,createdAt:Date.now()};
      db.users.push(user); saveDb(db);
      return json(res,201,{user:publicUser(user),token:tokenFor(user)});
    }
    if (req.method === 'POST' && req.url === '/auth/login') {
      const {email,password} = await readBody(req);
      const normalizedEmail = normalizeEmail(email);
      const user=loadDb().users.find(u=>normalizeEmail(u.email)===normalizedEmail);
      if (!user || !verifyPassword(String(password||''),user))
        return json(res,401,{error:'Correo o contraseña incorrectos.'});
      return json(res,200,{user:publicUser(user),token:tokenFor(user)});
    }
    if (req.method === 'GET' && req.url === '/me') {
      const u=authorizedUser(req); return u?json(res,200,{user:publicUser(u)}):json(res,401,{error:'No autorizado'});
    }
    if (req.method === 'DELETE' && req.url === '/me') {
      const u=authorizedUser(req); if(!u)return json(res,401,{error:'No autorizado'});
      const db=loadDb(); db.users=db.users.filter(item=>item.id!==u.id); saveDb(db);
      return json(res,200,{ok:true});
    }
    if (req.method === 'GET' && req.url === '/v1/models') {
      const u=authorizedUser(req);if(!u)return json(res,401,{error:'No autorizado'});
      const basic=[{id:'auto',name:'MultiAI Auto',tier:'free'}];
      const plus=[{id:'qwen3:1.7b',name:'Qwen 3 1.7B',tier:'plus'},
        {id:'gemma3:4b',name:'Gemma 3 4B',tier:'plus'},
        {id:'deepseek-r1:1.5b',name:'DeepSeek R1 1.5B',tier:'plus'},
        {id:'llama3.2:3b',name:'Llama 3.2 3B',tier:'plus'}];
      return json(res,200,{models:u.plan==='plus'?basic.concat(plus):basic,plan:u.plan});
    }
    if (req.method === 'POST' && req.url === '/v1/chat') {
      const u=authorizedUser(req);if(!u)return json(res,401,{error:'Inicia sesión.'});
      const {model='auto',messages=[]}=await readBody(req);
      if(model!=='auto'&&u.plan!=='plus')return json(res,403,{error:'Cambiar de modelo requiere PLUS.'});
      if(!Array.isArray(messages))return json(res,400,{error:'Mensajes inválidos.'});
      const selected=model==='auto'?DEFAULT_OLLAMA_MODEL:model;
      const response=await fetch(OLLAMA_URL+'/api/chat',{method:'POST',headers:{'content-type':'application/json'},
        body:JSON.stringify({model:selected,messages,stream:false})});
      const data=await response.json().catch(()=>({}));
      if(!response.ok)return json(res,502,{error:'El modelo de IA no está disponible.'});
      return json(res,200,{text:data.message?.content||'',model:selected});
    }
    return json(res,404,{error:'Ruta no encontrada'});
  } catch (error) {
    return json(res,error.status||500,{error:error.status?error.message:'Error interno del servidor.'});
  }
});
server.listen(PORT,'127.0.0.1',()=>console.log(`MultiAI v0.5.9 backend listening on 127.0.0.1:${PORT}`));
