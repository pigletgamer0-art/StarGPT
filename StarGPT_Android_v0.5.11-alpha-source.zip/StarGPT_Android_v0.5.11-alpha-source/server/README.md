# Servidor de cuentas MultiAI 0.5.7

`node server.js` inicia un servicio local en `127.0.0.1:8787`. Antes de arrancar, establece `TOKEN_SECRET` a una cadena aleatoria de al menos 32 caracteres y `MULTIAI_DB` a una ubicación persistente privada. Las cuentas se almacenan en el archivo JSON de esa ruta, exclusivamente en el servidor. Guarda una copia de seguridad protegida de ese archivo: si se pierde, las cuentas no se pueden recuperar.

Para usarlo desde Android en varios dispositivos, implementa un servidor **HTTPS** accesible por nombre de dominio y un proxy que termine TLS y pase las solicitudes al proceso local. No basta con ejecutar `node server.js` en un ordenador sin publicar el servicio. No hay ningún servidor público configurado en el APK incluido con este código. **Usa un solo proceso** con almacenamiento JSON: si implementas varias réplicas, cambia a una base de datos con índices UNIQUE para el nombre normalizado y el correo normalizado.

Datos almacenados: ID aleatorio, nombre, correo normalizado, hash de contraseña con scrypt y sal aleatoria, plan y fecha de registro. La contraseña original no se guarda. No se almacenan claves API ni el historial de conversaciones en el registro de cuentas. `DELETE /me`, con token Bearer, borra la cuenta de este servidor. El administrador es responsable de la información de privacidad, la protección de copias de seguridad y las políticas aplicables al servicio.

Las cuentas sin servidor son **solo locales**, sin unicidad global ni recuperación entre dispositivos. El backend incluye registro, inicio de sesión, consulta y borrado de cuenta y rutas de chat/modelos (estas últimas requieren Ollama configurado aparte). Implementa verificación de correo y mecanismos de recuperación y limitación de intentos antes de abrir un servicio público.


### Iniciar sesión con Google (v0.5.9)
Configura en el entorno `GOOGLE_WEB_CLIENT_ID` igual al Web Client ID de Android (`-PMULTIAI_GOOGLE_WEB_CLIENT_ID=...`). Usa servidor HTTPS. `POST /auth/google/lookup` recibe `{idToken}` y devuelve un perfil existente o `{needsName:true}`. `POST /auth/google/register` recibe `{idToken,name}` y crea el perfil solo si el ID token se verifica contra las claves públicas de Google, el aud/iss/exp son válidos y el correo está verificado. Para preservar seguridad no vincula una cuenta Google con otra cuenta por coincidencia de email. No almacena el token de Google.
